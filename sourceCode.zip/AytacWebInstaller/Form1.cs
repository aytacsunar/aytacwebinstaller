﻿using System;
using System.Windows.Forms;

namespace AytacWebInstaller
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public string uploadyolu { get; set; }
        private void Form1_Load(object sender, EventArgs e)
        {

            FtpCredentials frm = new FtpCredentials();
            frm.ShowDialog();
       //     ftpClientCtl1.openFileDialog1.InitialDirectory = uploadyolu;
            ftpClientCtl1.Host = Properties.Settings.Default.Host;
            ftpClientCtl1.Username = Properties.Settings.Default.Username;
            ftpClientCtl1.Password = Properties.Settings.Default.Password;
            ftpClientCtl1.DosyaYolu = uploadyolu;
            ftpClientCtl1.Populate();
        }
    }
}
