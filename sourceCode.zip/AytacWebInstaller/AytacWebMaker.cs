﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Security;
using System.Collections;
using System.Security.Cryptography;
using Ionic;
using Ionic.Zip;
using System.Net;
using System.Diagnostics;
using System.Threading;
using System.Reflection;

namespace AytacWebInstaller
{
    public partial class AytacWebMaker : Form
    {
        private System.ComponentModel.BackgroundWorker _backgroundWorker1;
        private bool _saveCanceled;
        private long _totalBytesAfterCompress;
        private long _totalBytesBeforeCompress;
        private int _nFilesCompleted;
        private int _progress2MaxFactor;
        private int _entriesToZip;
        private delegate void SaveEntryProgress(SaveProgressEventArgs e);
        private delegate void ButtonClick(object sender, EventArgs e);
        private int x = 1; 							// number for splits
        private long len = 0;						// the lengt of the original file
        private bool Parcalama = false;				// splitfile = true, mergefile = false
        private int eachSize = 0;					// max size of each file
        public const string updaterPrefix = "W1234_";
        private static string processToEnd = "AytacWebInstaller";
        private static string postProcess = Application.StartupPath + @"\" + processToEnd + ".exe";
        public static string updater = Application.StartupPath + @"\guncelle.exe";
        public const string updateSuccess = "Güncelleştirme başarıyla tamamlandı...";
        public const string updateCurrent = "En son sürümü kullanıyorsunuz.";
        public const string updateAvaible = "Güncelleştirmek için Güncelleştir butonuna basınız...";
        public const string updateInfoError = "Sunucuya bağlanılamadı. İnternet yok veya hatalı sunucu.";
        public static List<string> info = new List<string>();
        private void update_bttn_Click(object sender, EventArgs e)
        {
            update.installUpdateRestart(info[3], info[4], "\"" + Application.StartupPath + "\\", processToEnd, postProcess, "updated", updater);
            Close();
        }
        private void unpackCommandline()
        {
            bool commandPresent = false;
            string tempStr = "";
            foreach (string arg in Environment.GetCommandLineArgs())
            {
                if (!commandPresent)
                {
                    commandPresent = arg.Trim().StartsWith("/");
                }
                if (commandPresent)
                {
                    tempStr += arg;
                }
            }
            if (commandPresent)
            {
                if (tempStr.Remove(0, 2) == "updated")
                {
                    updateResult.Visible = true;
                    updateResult.Text = updateSuccess;
                }
            }
        }
        private void checkForUpdate_bttn_Click(object sender, EventArgs e)
        {
            info = update.getUpdateInfo(downloadsurl.Text, versionfilename.Text, Application.StartupPath + @"\", 1);
            if (info == null)
            {
                Update_bttn.Visible = false;
                updateResult.Text = updateInfoError;
                updateResult.Visible = true;
            }
            else
            {
                if (decimal.Parse(info[1]) > decimal.Parse(thisversion.Text))
                {
                    Update_bttn.Visible = true;
                    updateResult.Visible = true;
                    updateResult.Text = updateAvaible;
                }
                else
                {
                    Update_bttn.Visible = false;
                    updateResult.Visible = true;
                    updateResult.Text = updateCurrent;
                }
            }
        }
        public AytacWebMaker()
        {
            InitializeComponent();
        }
        string AytacWebinstaller = @"C:\AytacWebInstaller";
        string ProgramFilesKlasoru = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        string ProjeKodu = string.Empty;
     //   string Root = @"\AytacWebInstaller";
        string DownloadRootYolu = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        string DownloadYolu = string.Empty;
        string Projeler = @"\Projeler";
        string KurSablon = @"\KurSablon";
        string Kur = @"\Kur";
        string KurZip = @"\KurZip";
        string DataWeb = @"\DataWeb";
        string DataTemp = @"\DataTemp";
        string sikismisdosya = string.Empty;
        string ProjeYolu = string.Empty;
        string MasaustuKlasorYolu = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        string BaslatKlasorYolu = Environment.GetFolderPath(Environment.SpecialFolder.StartMenu);
        string StartUpYolu = Environment.GetFolderPath(Environment.SpecialFolder.Startup);
        public bool UygulamaKontrol() {
            if (!Directory.Exists(AytacWebinstaller + KurSablon))
            {
                return false;
            }
            else if (!File.Exists(AytacWebinstaller + KurSablon + @"\Interop.IWshRuntimeLibrary.dll"))
            {
                return false;
            }
            else if (!File.Exists(AytacWebinstaller + KurSablon + @"\Ionic.Zip.dll"))
            {
                return false;
            }
            else if (!File.Exists(AytacWebinstaller + KurSablon + @"\Kur.exe"))
            {
                return false;
            }
            return true;
        }
        public class ProgramTemel
        {
            public string ProjeAdi { get; set; }
            public string ProjeBaslik { get; set; }
            public string ProjeMevcutYolu { get; set; }
            public string ProjeYukleYolu { get; set; }
            public string ProjeKodu { get; set; }
            public string PaketAdi { get; set; }
            public string ProjePaketSayisi { get; set; }
            public string ProjeSahibi { get; set; }
            public string ProjeExeDosya { get; set; }
            public string ProjeVersiyon { get; set; }
            public string ProjeKisayolAdi { get; set; }
            public string ProjeWebYolu { get; set; }
            public string ProjeKaynakKlasor { get; set; }
            public string ProjeBulunduguYer { get; set; }
            public string ProjeYuklenenYer { get; set; }
            public string ToplamPaket { get; set; }
            public string Masaustu { get; set; }
            public string Baslangic { get; set; }
            public string Programlar { get; set; }
            public string UreticiAdi { get; set; }
            public string UreticiAdres { get; set; }
        }
        public class WorkerOptions
        {
            public string Folder;
            public string ZipName;
        }
        ProgramTemel ProjeNe = new ProgramTemel();
        public class Derlenmis
        {
            public string ProjeAdi { get; set; }
            public string ProjeBaslik { get; set; }
            public string ProjeYolu { get; set; }
            public string PaketAdi { get; set; }
            public int PaketSayisi { get; set; }
            public int MasaustuKisayol { get; set; }
            public string MasaustuKisaYolu { get; set; }
            public string ServerBilgi { get; set; }
            public string KaynakKlasor { get; set; }
            public string BulunduguYer { get; set; }
            public string YuklenenYer { get; set; }
            public int ToplamPaket { get; set; }
        }
        Hashtable ComboListe2 = new Hashtable();
        public string KodOlustur(string Text)
        {
            try
            {
                string strReturn = Text.Trim();
                strReturn = strReturn.Replace("ğ", "g");
                strReturn = strReturn.Replace("Ğ", "G");
                strReturn = strReturn.Replace("ü", "u");
                strReturn = strReturn.Replace("Ü", "U");
                strReturn = strReturn.Replace("ş", "s");
                strReturn = strReturn.Replace("Ş", "S");
                strReturn = strReturn.Replace("ı", "i");
                strReturn = strReturn.Replace("İ", "I");
                strReturn = strReturn.Replace("ö", "o");
                strReturn = strReturn.Replace("Ö", "O");
                strReturn = strReturn.Replace("ç", "c");
                strReturn = strReturn.Replace("Ç", "C");
                strReturn = strReturn.Replace("-", "+");
                strReturn = strReturn.Replace(" ", "+");
                strReturn = strReturn.Trim();
                strReturn = new System.Text.RegularExpressions.Regex("[^a-zA-Z0-9+]").Replace(strReturn, "");
                strReturn = strReturn.Trim();
                strReturn = strReturn.Replace("+", "");
                return strReturn;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void DoSave(object sender, DoWorkEventArgs e)
        {
            WorkerOptions options = (WorkerOptions)e.Argument;
            try
            {
                using (ZipFile zip1 = new ZipFile())
                {
                    zip1.AddDirectory(options.Folder);
                    this._entriesToZip = zip1.EntryFileNames.Count;
                    this.SetProgressBars();
                    zip1.SaveProgress += new EventHandler<SaveProgressEventArgs>(this.zip1_SaveProgress);
                    zip1.Save(options.ZipName);
                }
            }
            catch (Exception exc1)
            {
                MessageBox.Show(string.Format("Sıkıştırma sırasında hata oluştu: {0}", exc1.Message));
                this.button5_Click(null, null);
            }
        }
        private void zip1_SaveProgress(object sender, SaveProgressEventArgs e)
        {
            if (this._saveCanceled)
            {
                e.Cancel = true;
                return;
            }

            switch (e.EventType)
            {
                case ZipProgressEventType.Saving_AfterWriteEntry:
                    this.StepArchiveProgress(e);
                    break; // TODO: might not be correct. Was : Exit Select

                //  break;
                case ZipProgressEventType.Saving_Completed:
                    this.SaveCompleted();
                    break; // TODO: might not be correct. Was : Exit Select

                //    break;
                case ZipProgressEventType.Saving_EntryBytesRead:
                    this.StepEntryProgress(e);
                    break; // TODO: might not be correct. Was : Exit Select

                //    break;
            }
        }
        private void StepArchiveProgress(SaveProgressEventArgs e)
        {
            if (this.progressBar1.InvokeRequired)
            {
                this.progressBar1.Invoke(new SaveEntryProgress(this.StepArchiveProgress), new object[] { e });
            }
            else if (!this._saveCanceled)
            {
                this._nFilesCompleted += 1;
                this.progressBar1.PerformStep();
                this._totalBytesAfterCompress = (this._totalBytesAfterCompress + e.CurrentEntry.CompressedSize);
                this._totalBytesBeforeCompress = (this._totalBytesBeforeCompress + e.CurrentEntry.UncompressedSize);
                // ProgressBar2 is the one dealing with the item being added to the archive
                // if we got this event, then the add of that item (or file) is complete, so we 
                // update the ProgressBar2 appropriately.
                this.progressBar2.Value = 1;
                base.Update();
            }
        }
        private void SaveCompleted()
        {
            if (this.lblDurum.InvokeRequired)
            {
                this.lblDurum.Invoke(new MethodInvoker(SaveCompleted));
                //Me.lblStatus.Invoke(New MethodInvoker(Me, DirectCast(Me.SaveCompleted, IntPtr)))
            }
            else
            {
                this.lblDurum.Text = string.Format(" {0} dosya sıkıştırıldı., Orjinal boyutu: % {1:N0}", this._nFilesCompleted, ((100 * this._totalBytesAfterCompress) / Convert.ToDouble(this._totalBytesBeforeCompress)));
                this.lblSikistirSonra.Text = "Dosya sıkıştırma tamamlandı. Bir sonraki aşama olan PARÇALAMA işlemine geçiniz!";
                this.ResetState();
            }
        }
        private void StepEntryProgress(SaveProgressEventArgs e)
        {
            if (this.progressBar2.InvokeRequired)
            {
                this.progressBar2.Invoke(new SaveEntryProgress(this.StepEntryProgress), new object[] { e });
            }
            else if (!this._saveCanceled)
            {
                if ((this.progressBar2.Maximum == 1))
                {
                    long entryMax = e.TotalBytesToTransfer;
                    long absoluteMax = 0x7fffffff;
                    this._progress2MaxFactor = 0;
                    while ((entryMax > absoluteMax))
                    {
                        entryMax = (entryMax / 2);
                        this._progress2MaxFactor += 1;
                    }
                    if ((Convert.ToInt32(entryMax) < 0))
                    {
                        entryMax = (entryMax * -1);
                    }
                    this.progressBar2.Maximum = Convert.ToInt32(entryMax);
                    this.lblDurum.Text = string.Format("{0} dosyadan {1} dosya sıkıştırıldı...({2})",this._entriesToZip, (this._nFilesCompleted + 1),  e.CurrentEntry.FileName);
                }
                this.lblSikistirSonra.Text = string.Format("({0})", e.CurrentEntry.FileName);
                int xferred = Convert.ToInt32((e.BytesTransferred >> this._progress2MaxFactor));
                progressBar2.Value = ((xferred >= this.progressBar2.Maximum) ? this.progressBar2.Maximum : xferred);
                base.Update();
            }
        }
        private void ResetState()
        {
            this.btnIptal.Enabled = false;
            this.btnPaketle.Enabled = false;
            this.btnPaketle.Text = "Sıkıştırma İşlemini Başlat!";
            this.progressBar1.Value = 0;
            this.progressBar2.Value = 0;
            Parcalama = true;
            txtParcaSayisi.Enabled = true;
            this.Cursor = Cursors.Default;
        }
        private void SetProgressBars()
        {
            if (this.progressBar1.InvokeRequired)
            {
                //Me.ProgressBar1.Invoke(New MethodInvoker(Me, DirectCast(Me.SetProgressBars, IntPtr)))
                this.progressBar1.Invoke(new MethodInvoker(SetProgressBars));
            }
            else
            {
                this.progressBar1.Value = 0;
                this.progressBar1.Maximum = this._entriesToZip;
                this.progressBar1.Minimum = 0;
                this.progressBar1.Step = 1;
                this.progressBar2.Value = 0;
                this.progressBar2.Minimum = 0;
                this.progressBar2.Maximum = 1;
                this.progressBar2.Step = 2;
            }
        }
        public static string MD5Hash(string DuzYazi)
        {
            // Use input string to calculate MD5 hash
            MD5 md5 = System.Security.Cryptography.MD5.Create();
            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(DuzYazi + string.Format("{0:yyyyMMdd}", DateTime.Today));
            byte[] hashBytes = md5.ComputeHash(inputBytes);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hashBytes.Length; i++)
            {
                sb.Append(hashBytes[i].ToString("X2"));
            }
            return sb.ToString();
        }
        public void projeleriyukle()
        {
            ComboListe2.Clear();
            DirectoryInfo dir = new DirectoryInfo(AytacWebinstaller + Projeler);
            foreach (DirectoryInfo di in dir.GetDirectories())
            {
                try
                {
                    var MyIni = new IniSinif(AytacWebinstaller + Projeler + @"\" + di.Name + Kur + @"\Ayarlar.ini");
                    var ProjeBasligiini = MyIni.Read("ProjeBaslik", "PROJE");
                    if (ProjeBasligiini.Length > 0)
                    {
                        ComboListe2.Add(ProjeBasligiini.ToString(), di.Name);
                    }
                }
                catch (Exception)
                {
                   // label1.Text = "";
                }
            }
        }
        public void comboguncelle()
        {
            comboProje.Items.Clear();
            foreach (DictionaryEntry Projecikler in ComboListe2)
            {
                comboProje.Items.Add(Projecikler);
            }
            comboProje.DisplayMember = "key";
            comboProje.ValueMember = "value";
        }
        internal string GetFromResources(string resourceName)
        {
            Assembly assem = this.GetType().Assembly;
            using (Stream stream = assem.GetManifestResourceStream(resourceName))
            {
                using (var reader = new StreamReader(stream))
                {
                    return reader.ReadToEnd();
                }
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            //panel4.Controls.Add(ftpClientCtl1);
            string lisansne = AytacWebInstaller.Properties.Resources.Lisans;
            txtProgLisans.Text = lisansne;
            lblVersiyonNedir.Text = Application.ProductVersion;
            thisversion.Text = Application.ProductVersion;
            update.updateMe(updaterPrefix, Application.StartupPath + @"\");
            updateResult.Visible = false;
            Update_bttn.Visible = false;
            unpackCommandline();
            try
            {
                info = update.getUpdateInfo(downloadsurl.Text, versionfilename.Text, Application.StartupPath + @"\", 1);
                if (info == null)
                {
                    Update_bttn.Visible = false;
                    updateResult.Text = updateInfoError;
                    updateResult.Visible = true;
                }
                else
                {
                    if (decimal.Parse(info[1]) > decimal.Parse(thisversion.Text))
                    {
                        Update_bttn.Visible = true;
                        updateResult.Visible = true;
                        updateResult.Text = updateAvaible;
                        MessageBox.Show("Yeni güncelleştirmeler mevcut.");
                        tabControl1.SelectedIndex = 6;
                    }
                    else
                    {
                        Update_bttn.Visible = false;
                        updateResult.Visible = true;
                        updateResult.Text = updateCurrent;
                    }
                }
            }
            catch (Exception)
            {

            }
//            Assembly assembly = Assembly.GetExecutingAssembly();
//            Stream stream =
//this.GetType().Assembly.GetManifestResourceStream("AytacWebInstaller.Properties.Resources.Sozlesme");

//            if (stream != null)
//            {
//                StreamReader sr = new StreamReader(stream);
//                txtProgLisans.LoadFile(stream, RichTextBoxStreamType.RichText);
//                sr.Close();
//            }
//            else
//                MessageBox.Show("Could not load resource.");
       //     txtProgLisans.Text = GetFromResources("AytacWebInstaller.Properties.Resources.Sozlesme");

            //     StreamReader okuyucu = new StreamReader(assembly.GetManifestResourceStream());//new StreamReader(AytacWebInstaller.Properties.Resources.sozlesme);
            //txtProgLisans.Text = okuyucu.ReadToEnd();
            //okuyucu.Close();
            toolTip1.SetToolTip(btnTestEt,"Oluşturduğunuz kur dosyanını test edin!");
            toolTip1.SetToolTip(btnKurKlasor, "Oluşturduğunuz kurulum için gerekli olan dosyalara gözatınız!");
            toolTip1.SetToolTip(btnWebGoster, "Oluşturduğunuz projenin web alanına atılacak bölümlerini gözatınız!\nBu dosyaları upload etmezseniz uygulamanız kurulamaz!");
            if (UygulamaKontrol())
            {
                            projeleriyukle();
            comboguncelle();
            }
            else
            {
                comboProje.Enabled = false;
                btnProjeOlustur.Enabled = false;
                btnProjeKaydet.Enabled = false;
                MessageBox.Show("Uygulamanın bazı dosyaları eksik!\nLütfen AytacWebInstaller uygulamasını yeniden kurunuz!\nDetaylı bilgi için:\nhttp://www.aytacsunar.com/AytacWebInstaller");
            }
        }
        //private void button1_Click(object sender, EventArgs e)
        //{
        //    ProjeKodu = MD5Hash("DENEME");
        //    if (!Directory.Exists(DownloadRootYolu + DownloadYolu + Root + Projeler + @"\" + ProjeKodu))
        //    {
        //        Directory.CreateDirectory(DownloadRootYolu + DownloadYolu + Root + Projeler + @"\" + ProjeKodu);
        //    }
        //}
        private void button2_Click(object sender, EventArgs e)
        {
            string folderName = this.txtProjeYolu.Text;
            FolderBrowserDialog dlg1 = new FolderBrowserDialog();
            dlg1.SelectedPath = (Directory.Exists(folderName) ? folderName : "c:\\");
            dlg1.ShowNewFolderButton = false;
            DialogResult result = dlg1.ShowDialog();
            if (result == DialogResult.OK)
            {
                ProjeNe.ProjeMevcutYolu = dlg1.SelectedPath;
            }
            txtProjeYolu.Text = ProjeNe.ProjeMevcutYolu;
            ProjeNe.ProjeMevcutYolu = txtProjeYolu.Text.Trim();
        }
        private void button3_Click(object sender, EventArgs e)
        {
           // openFileDialog1.Tag = "Lütfen çalıştırılacak dosyayı seçiniz!";
            openFileDialog1.InitialDirectory = ProjeNe.ProjeMevcutYolu;
            openFileDialog1.CheckFileExists = true;
            openFileDialog1.FileName = "Dosya Seçiniz";
            openFileDialog1.Title = "Proje Başlatma EXE dosyasını seçiniz!";
            openFileDialog1.Filter = "Program Dosyası (*.exe)|*.exe|Program Kur Dosyası (*.msi)|*.msi|Tüm Dosyalar (*.*)|*.*";
        //    openFileDialog1.InitialDirectory = ProjeYolu;
            openFileDialog1.Multiselect = false;
            DialogResult sonuc = openFileDialog1.ShowDialog();
            string ayniyol = string.Empty;
            if (sonuc == DialogResult.OK)
            {
              //  ayniyol = openFileDialog1.InitialDirectory;
                FileInfo secilmisdosya = new FileInfo(openFileDialog1.FileName);
                ayniyol = secilmisdosya.FullName;
                string sonsecim = string.Empty;
                if (ayniyol.Contains(ProjeNe.ProjeMevcutYolu))
                {
                 //   MessageBox.Show("DOĞRU SEÇİM");
                    sonsecim = ayniyol.Substring(ProjeNe.ProjeMevcutYolu.Length+1);
                    txtProgramEXE.Text = sonsecim;//openFileDialog1.SafeFileName; 
                }
                else
                {
                    MessageBox.Show("Lütfen seçiminizi Mevcut Klasör içindeki dosyalardan yapınız!");
                    txtProgramEXE.Text = string.Empty;
                }
            }
        }
        private void btnProjeOlustur_Click(object sender, EventArgs e)
        {
            string ProjeAdine = comboProje.Text.Trim();//txtProjeAdi.Text.Trim();
            if (ProjeAdine.Length > 5)
            {
                ProjeNe.ProjeAdi = KodOlustur(ProjeAdine);
                ProjeNe.ProjeBaslik = ProjeAdine;
                btnExeSec.Enabled = true;
                btnMevcutBul.Enabled = true;
                btnProjeOlustur.Enabled = true;
                btnYukleBul.Enabled = true;
                txtProjeBaslik.Enabled = true;
                txtCopyRight.Enabled = true;
                txtKisayolAdi.Enabled = true;
          //      txtKurulumBilgi.Enabled = true;
                txtProgramEXE.Enabled = true;
                txtProgramVersiyon.Enabled = true;
            //    txtProjeAdi.Enabled = true;
                txtProjeYolu.Enabled = true;
                txtProjeYukle.Enabled = true;
                txtServerBilgi.Enabled = true;
                txtDestekText.Enabled = true;
                txtDestekUrl.Enabled = true;
                txtLisansSozlesmesi.Enabled = true;
                cbDesktop.Enabled = true;
                cbPrograms.Enabled = true;
                cbStartup.Enabled = true;
                if (!Directory.Exists(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi))
                {
                    Directory.CreateDirectory(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi);
                    Directory.CreateDirectory(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi +Kur);
                    File.Copy(AytacWebinstaller + KurSablon + @"\Kur.exe", AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi +Kur+ @"\Kur.exe", true);
                    File.Copy(AytacWebinstaller + KurSablon + @"\Interop.IWshRuntimeLibrary.dll", AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi +Kur+ @"\Interop.IWshRuntimeLibrary.dll", true);
                    File.Copy(AytacWebinstaller + KurSablon + @"\Ionic.Zip.dll", AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + Kur+ @"\Ionic.Zip.dll", true);
                    var IniYaz = new IniSinif(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi +Kur+ @"\Ayarlar.ini");
                    IniYaz.Write("ProjeAdi", ProjeNe.ProjeAdi, "PROJE");
                    IniYaz.Write("ProjeBaslik", ProjeNe.ProjeBaslik, "PROJE");
                    IniYaz.Write("ProjeKodu", MD5Hash(ProjeNe.ProjeAdi), "PROJE");
                    IniYaz.Write("ProjeMevcutYolu", ProjeNe.ProjeMevcutYolu, "PROJE");
                    IniYaz.Write("ProjeYukleYolu", ProjeNe.ProjeYukleYolu, "PROJE");
                    IniYaz.Write("ProjeSahibi", ProjeNe.ProjeSahibi, "PROJE");
                    IniYaz.Write("ProjeVersiyon", ProjeNe.ProjeVersiyon, "PROJE");
                    IniYaz.Write("ProjeExeDosya", ProjeNe.ProjeExeDosya, "PROJE");
                    IniYaz.Write("ProjeKisayolAdi", ProjeNe.ProjeKisayolAdi, "PROJE");
                    IniYaz.Write("ProjeMasaustu", ProjeNe.Masaustu, "PROJE");
                    IniYaz.Write("ProjeProgramlar", ProjeNe.Programlar, "PROJE");
                    IniYaz.Write("ProjeBaslangic", ProjeNe.Baslangic, "PROJE");
                    IniYaz.Write("ProjePaketSayisi", ProjeNe.ProjePaketSayisi, "PROJE");
                    IniYaz.Write("ProjeWebYolu", ProjeNe.ProjeWebYolu, "PROJE");
                    IniYaz.Write("DestekText", ProjeNe.UreticiAdi, "PROJE");
                    IniYaz.Write("DestekUrl", ProjeNe.UreticiAdres, "PROJE");
                }
                else
                {
                    var IniOku = new IniSinif(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi +Kur+ @"\Ayarlar.ini");
                    var iniProjeAdi = IniOku.Read("ProjeAdi", "PROJE");
                    var iniProjeBaslik = IniOku.Read("ProjeBaslik", "PROJE");
                    var iniProjeKodu = IniOku.Read("ProjeKodu", "PROJE");
                    var iniProjeMevcutYolu = IniOku.Read("ProjeMevcutYolu", "PROJE");
                    var iniProjeYukleYolu = IniOku.Read("ProjeYukleYolu", "PROJE");
                    var iniProjeSahibi = IniOku.Read("ProjeSahibi", "PROJE");
                    var iniProjeVersiyon = IniOku.Read("ProjeVersiyon", "PROJE");
                    var iniProjeExeDosya = IniOku.Read("ProjeExeDosya", "PROJE");
                    var iniKisayolAdi = IniOku.Read("ProjeKisayolAdi", "PROJE");
                    var iniProjeMasaustu = IniOku.Read("ProjeMasaustu", "PROJE");
                    var iniProjeProgramlar = IniOku.Read("ProjeProgramlar", "PROJE");
                    var iniProjeBaslangic = IniOku.Read("ProjeBaslangic", "PROJE");
                    var iniProjePaketSayisi = IniOku.Read("ProjePaketSayisi", "PROJE");
                    var iniProjeWebYolu = IniOku.Read("ProjeWebYolu", "PROJE");
                    var iniDestekText = IniOku.Read("DestekText", "PROJE");
                    var iniDestekUrl = IniOku.Read("DestekUrl", "PROJE");
                    ProjeNe.ProjeAdi = iniProjeAdi.ToString();
                    ProjeNe.ProjeBaslik = iniProjeBaslik.ToString();
                    ProjeNe.ProjeKodu = iniProjeKodu.ToString();
                    ProjeNe.ProjeMevcutYolu = iniProjeMevcutYolu.ToString();
                    ProjeNe.ProjeYukleYolu = iniProjeYukleYolu.ToString();
                    ProjeNe.ProjeSahibi = iniProjeSahibi.ToString();
                    ProjeNe.ProjeVersiyon = iniProjeVersiyon.ToString();
                    ProjeNe.ProjeExeDosya = iniProjeExeDosya.ToString();
                    ProjeNe.ProjeKisayolAdi = iniKisayolAdi.ToString();
                    ProjeNe.Masaustu = iniProjeMasaustu.ToString();
                    ProjeNe.Programlar = iniProjeProgramlar.ToString();
                    ProjeNe.Baslangic = iniProjeBaslangic.ToString();
                    ProjeNe.ProjePaketSayisi = iniProjePaketSayisi.ToString();
                    ProjeNe.ProjeWebYolu = iniProjeWebYolu.ToString();
                    ProjeNe.UreticiAdi = iniDestekText.ToString();
                    ProjeNe.UreticiAdres = iniDestekUrl.ToString();
                    if (ProjeNe.Masaustu == "1") cbDesktop.Checked = true; else cbDesktop.Checked = false;
                    if (ProjeNe.Programlar == "1") cbPrograms.Checked = true; else cbPrograms.Checked = false;
                    if (ProjeNe.Baslangic == "1") cbStartup.Checked = true; else cbStartup.Checked = false;
                    txtProjeBaslik.Text = ProjeNe.ProjeBaslik;
                    txtCopyRight.Text = ProjeNe.ProjeSahibi;
                    txtKisayolAdi.Text = ProjeNe.ProjeKisayolAdi;
                    txtProgramEXE.Text = ProjeNe.ProjeExeDosya;
                    txtProgramVersiyon.Text = ProjeNe.ProjeVersiyon;
                    //      txtProjeAdi.Text = ProjeNe.ProjeBaslik;
                    txtProjeYolu.Text = ProjeNe.ProjeMevcutYolu;
                    txtProjeYukle.Text = ProjeNe.ProjeYukleYolu;
                    txtParcaSayisi.Text = ProjeNe.ProjePaketSayisi;
                    txtServerBilgi.Text = ProjeNe.ProjeWebYolu;
                    txtDestekText.Text = ProjeNe.UreticiAdi;
                    txtDestekUrl.Text = ProjeNe.UreticiAdres;
                    FileInfo sozlesme = new FileInfo(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi +Kur+ @"\sozlesme.txt");
                    if (sozlesme.Exists)
                    {
                        StreamReader okuyucu = new StreamReader(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi +Kur+ @"\sozlesme.txt");
                        txtLisansSozlesmesi.Text = okuyucu.ReadToEnd();
                        okuyucu.Close();
                    }
                    else
                    {
                        txtLisansSozlesmesi.Text = "Lisans sözleşme metni giriniz!";
                    }
                }
                projeleriyukle();
                comboguncelle();
                lblProjeDurum.Text = "Proje bilgilerinin girilmesi Proje Kaydet butonuna basılması bekleniyor...";
            //    label1.Text = ProjeNe.ProjeBaslik;
           //     label1.Text += ProjeNe.ProjeAdi;
            }
            else
            {
                MessageBox.Show("Proje adınız en az 6 karakterli olmalıdır.\nVeya listeden proje seçmediniz.\n" + HataNe);
            }

        }
        public void ProjeOku()
        {
            var IniOku = new IniSinif(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + Kur+@"\Ayarlar.ini");
            var iniProjeAdi = IniOku.Read("ProjeAdi", "PROJE");
            var iniProjeBasligi = IniOku.Read("ProjeBasligi", "PROJE");
            var iniProjeKodu = IniOku.Read("ProjeKodu", "PROJE");
            var iniProgramMevcutDizin = IniOku.Read("ProgramMevcutDizin", "PROJE");
            var iniProgramExeDosya = IniOku.Read("ProgramExeDosya", "PROJE");
            var iniProgramYukleDizini = IniOku.Read("ProgramYukleDizini", "PROJE");
            var iniKisayolAdi = IniOku.Read("KisayolAdi", "PROJE");
            var iniProgramVersiyon = IniOku.Read("ProgramVersiyon", "PROJE");
            var iniProgramSahibi = IniOku.Read("ProgramSahibi", "PROJE");
            var iniProgramHTTP = IniOku.Read("ProgramHTTP", "PROJE");
            var iniYuklenenYer = IniOku.Read("YuklenenYer", "PROJE");
            ProjeNe.ProjeAdi = iniProjeAdi.ToString();
            ProjeNe.ProjeBaslik = iniProjeBasligi.ToString();
            ProjeNe.ProjeKodu = iniProjeKodu.ToString();
            ProjeNe.ProjeMevcutYolu = iniProgramMevcutDizin.ToString();
            ProjeNe.ProjeExeDosya = iniProgramExeDosya.ToString();
            ProjeNe.ProjeYukleYolu = iniProgramYukleDizini.ToString();
            ProjeNe.ProjeKisayolAdi = iniKisayolAdi.ToString();
            ProjeNe.ProjeVersiyon = iniProgramVersiyon.ToString();
            ProjeNe.ProjeSahibi = iniProgramSahibi.ToString();
            ProjeNe.ProjeWebYolu = iniProgramHTTP.ToString();
            txtProjeBaslik.Text = ProjeNe.ProjeBaslik;
            txtCopyRight.Text = ProjeNe.ProjeSahibi;
            txtKisayolAdi.Text = ProjeNe.ProjeKisayolAdi;
            txtProgramEXE.Text = ProjeNe.ProjeExeDosya;
            txtProgramVersiyon.Text = ProjeNe.ProjeVersiyon;

      //      txtProjeAdi.Text = ProjeNe.ProjeBaslik;
            txtProjeYolu.Text = ProjeNe.ProjeMevcutYolu;
            txtProjeYukle.Text = ProjeNe.ProjeYukleYolu;

        }
        private void comboProje_DropDownClosed(object sender, EventArgs e)
        {
            string Secilen = string.Empty;
            btnProjeOlustur.Enabled = true;
            //   ProjeCombo yeni = new ProjeCombo();
            try
            {
                //yeni = (ProjeCombo)comboProje.SelectedItem;
                //Secilen = yeni.Value;
                DictionaryEntry secilmis = (DictionaryEntry)comboProje.SelectedItem;
                Secilen = secilmis.Value.ToString();
            }
            catch (Exception)
            {
                Secilen = KodOlustur("Yeni Proje " + String.Format("{0:yyyyMMdd}", DateTime.Today));
            }

            if (Secilen != ProjeNe.ProjeAdi)
            {
                if (!Directory.Exists(AytacWebinstaller + Projeler + @"\" + Secilen))
                {
                    //Directory.CreateDirectory(AytacWebinstaller + Projeler + @"\" + Secilen);
                    //var IniYaz = new IniSinif(AytacWebinstaller + Projeler + @"\" + Secilen + @"\Ayarlar.ini");
                    //IniYaz.Write("ProjeAdi", Secilen, "PROJE");
                    //IniYaz.Write("ProjeBasligi", "Yeni Proje " + String.Format("{0:yyyyMMdd}", DateTime.Today), "PROJE");
                    //IniYaz.Write("ProjeKodu", MD5Hash(Secilen), "PROJE");
                    //IniYaz.Write("ProgramMevcutDizin", "", "PROJE");
                    //IniYaz.Write("ProgramExeDosya", "", "PROJE");
                    //IniYaz.Write("ProgramYukleDizini", "", "PROJE");
                    //IniYaz.Write("KisayolAdi", "", "PROJE");
                    //IniYaz.Write("ProgramVersiyon", "", "PROJE");
                    //IniYaz.Write("ProgramSahibi", "", "PROJE");
                    //IniYaz.Write("ProgramHTTP", "", "PROJE");
                    //projeleriyukle();
                    //comboguncelle();
                }
                else
                {
                    ProjeNe.ProjeAdi = Secilen;
                    ProjeOku();
                    //var IniOku = new IniSinif(AytacWebinstaller + Projeler + @"\" + Secilen + @"\Ayarlar.ini");
                    //var iniProjeAdi = IniOku.Read("ProjeAdi", "PROJE");
                    //var iniProjeBasligi = IniOku.Read("ProjeBasligi", "PROJE");
                    //var iniProjeKodu = IniOku.Read("ProjeKodu", "PROJE");
                    //var iniProgramMevcutDizin = IniOku.Read("ProgramMevcutDizin", "PROJE");
                    //var iniProgramExeDosya = IniOku.Read("ProgramExeDosya", "PROJE");
                    //var iniProgramYukleDizini = IniOku.Read("ProgramYukleDizini", "PROJE");
                    //var iniKisayolAdi = IniOku.Read("KisayolAdi", "PROJE");
                    //var iniProgramVersiyon = IniOku.Read("ProgramVersiyon", "PROJE");
                    //var iniProgramSahibi = IniOku.Read("ProgramSahibi", "PROJE");
                    //var iniProgramHTTP = IniOku.Read("ProgramHTTP", "PROJE");
                    //var iniYuklenenYer = IniOku.Read("YuklenenYer", "PROJE");
                    //ProjeNe.ProjeAdi = iniProjeAdi.ToString();
                    //ProjeNe.ProjeBaslik = iniProjeBasligi.ToString();
                    //ProjeNe.ProjeKodu = iniProjeKodu.ToString();
                    //ProjeNe.ProjeMevcutYolu = iniProgramMevcutDizin.ToString();
                    //ProjeNe.EXEDosya = iniProgramExeDosya.ToString();
                    //ProjeNe.ProjeYukleYolu = iniProgramYukleDizini.ToString();
                    //ProjeNe.MasaustuKisaYolu = iniKisayolAdi.ToString();
                    //ProjeNe.Versiyon = iniProgramVersiyon.ToString();
                    //ProjeNe.ProjeSahibi = iniProgramSahibi.ToString();
                    //ProjeNe.ServerBilgi = iniProgramHTTP.ToString();
                    //txtProjeBaslik.Text = ProjeNe.ProjeBaslik;
                    //txtCopyRight.Text = ProjeNe.ProjeSahibi;
                    //txtKisayolAdi.Text = ProjeNe.MasaustuKisaYolu;
                    //txtProgramEXE.Text = ProjeNe.EXEDosya;
                    //txtProgramVersiyon.Text = ProjeNe.Versiyon;
                    //txtProjeAdi.Text = ProjeNe.ProjeBaslik;
                    //txtProjeYolu.Text = ProjeNe.ProjeMevcutYolu;
                    //txtProjeYukle.Text = ProjeNe.ProjeYukleYolu;
                }
            }
            else
            {
          //      label1.Text = "aynı proje";
            }


        }
        private void button5_Click(object sender, EventArgs e)
        {
            if (this.lblDurum.InvokeRequired)
            {
                this.lblDurum.Invoke(new ButtonClick(this.button5_Click), new object[] {
				sender,
				e
			});
            }
            else
            {
                this._saveCanceled = true;
                this.lblDurum.Text = "İşlem iptal edildi...";
                this.ResetState();
            }
        }
        private void btnPaketle_Click(object sender, EventArgs e)
        {
            sikismisdosya = AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + DataTemp + @"\Data1.zip";
            if (btnPaketle.Text == "Mevcut. Yeniden Sıkıştır?")
            {
                DialogResult sikitirsinmi = MessageBox.Show("Sıkıştırılmış mevcut bir dosya bulundu.\nProgramınızda herhangi bir değişiklik yaptınız mı?\nYaptığınız değişiklerin geçerli olmasını onaylıyor musunuz?", "UYARI", MessageBoxButtons.YesNo);
                if (sikitirsinmi == DialogResult.Yes)
                {
                    this.KickoffZipup();
                }
                else
                {
                    Parcalama = true;
                    txtParcaSayisi.Enabled = true;
                    btnPaketle.Enabled = false;
                }
            }
            else
            {
                this.KickoffZipup();
            }
            tabControl1.SelectedIndex = 4;
            lblProjeDurum.Text = "Proje web parçalarının hazırlanması bekleniyor... Parça sayısının girilmesi bekleniyor...";
        }
        private void KickoffZipup()
        {  
            string folderName = ProjeNe.ProjeMevcutYolu;
            string sikismisklasor = AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + DataTemp;
            if (!Directory.Exists(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi +  DataTemp))
            {
                Directory.CreateDirectory(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + DataTemp);
            }
            if (((((folderName != null)) && (!string.IsNullOrEmpty(folderName))) && (((sikismisdosya != null)) && (!string.IsNullOrEmpty(sikismisdosya)))))
            {
                this._saveCanceled = false;
                this._nFilesCompleted = 0;
                this._totalBytesAfterCompress = 0;
                this._totalBytesBeforeCompress = 0;
                this.btnPaketle.Enabled = false;
                this.btnPaketle.Text = "Sıkıştırılıyor...";
                this.btnIptal.Enabled = true;
                this.lblDurum.Text = "Sıkıştırılıyor...";
                WorkerOptions options = new WorkerOptions();
                options.ZipName = sikismisdosya;
                options.Folder = folderName;

                _backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
                _backgroundWorker1.WorkerSupportsCancellation = false;
                _backgroundWorker1.WorkerReportsProgress = false;
                this._backgroundWorker1.DoWork += new DoWorkEventHandler(this.DoSave);
                _backgroundWorker1.RunWorkerAsync(options);
            }
        }
        private bool SikismisDosyaKontrol()
        {
            FileInfo sikisan = new FileInfo(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + DataTemp + @"\Data1.zip");
            if (sikisan.Exists)
            {
                sikismisdosya = AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + DataTemp + @"\Data1.zip";
            }
            if (sikismisdosya.Length == 0 || txtParcaSayisi.Text.Length == 0)
            {
                lblParcaSayisi.Text = "Sıkıştırılmış dosya bulunamadı veya Parça sayısı girilmedi.";
                btnParcalamaBaslat.Enabled = false;
                return false;
            }
            try
            {
                x = Convert.ToInt32(txtParcaSayisi.Text);
            }
            catch (Exception ex)
            {
                lblParcaSayisi.Text = "Sadece rakam giriniz!";
                Console.WriteLine("The exception => " + ex);
                btnParcalamaBaslat.Enabled = false;
                return false;
            }

            Boolean fileExists = File.Exists(sikismisdosya);
            if (fileExists == false)
            {
                lblParcaSayisi.Text = "Sıkıştırılmış " + sikismisdosya + " dosya bulunamadı.";
                btnParcalamaBaslat.Enabled = false;
                return false;
            }
            return true;
        }
        private void DizinTemizle(string FolderName)
        {
            DirectoryInfo dir = new DirectoryInfo(FolderName);

            foreach (FileInfo fi in dir.GetFiles())
            {
                fi.Delete();
            }

            foreach (DirectoryInfo di in dir.GetDirectories())
            {
                DizinTemizle(di.FullName);
                di.Delete();
            }
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (SikismisDosyaKontrol())
            {
                if (Parcalama)
                {
                    using (FileStream fileStream = File.OpenRead(sikismisdosya))
                    {
                        len = fileStream.Length;
                    }
                    try
                    {
                        x = Convert.ToInt32(txtParcaSayisi.Text);
                    }
                    catch (Exception ex)
                    {
                        lblParcaSayisi.Text = "Sadece rakam giriniz!";
                        Console.WriteLine("The exception => " + ex);
                        btnParcalamaBaslat.Enabled = false;
                    }
                    eachSize = (int)Math.Ceiling((double)len / x);
                    lblParcaSayisi.Visible = true;
                    lblParcaSayisi.Text = len+" bytelık dosyayı " +txtParcaSayisi.Text.Trim() + " adede göre her parçanın boyutu: " + eachSize + " byte olacaktır.";
                    btnParcalamaBaslat.Enabled = true;
                }
                lblProjeDurum.Text = "Parçalamana işleminin başlatılması için Parçalama İşlemini Başlat butonu bekleniyor...";
            }
        }
        public bool ProjeKontrolEtUygunluk()
        {
            if (ProjeNe.ProjeYukleYolu.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.ProjeMevcutYolu.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.ProjeSahibi.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.ProjeVersiyon.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.ProjeExeDosya.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.ProjeAdi.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.ProjeBaslik.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.ProjeKisayolAdi.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.UreticiAdi.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.UreticiAdres.Length == 0)
            {
                return false;
            }
            return true;
        }
        public string HataNe = string.Empty;
        public bool ProjeKontrolEtKaydet()
        {
            HataNe = string.Empty;
            if (comboProje.Text.Trim().Trim().Length == 0)
            {
                HataNe += "\nProje Seçilmemiş";
                return false;

            }
            else if (txtProjeBaslik.Text.Trim().Length == 0)
            {
                HataNe += "\nBaşlık";
                return false;
            }
            else if (txtProjeYolu.Text.Trim().Length == 0)
            {
                HataNe += "\nMevcut Klasör";
                return false;
            }
            else if (txtProgramEXE.Text.Trim().Length == 0)
            {
                HataNe += "\nExe dosya";
                return false;
            }
            else if (txtProjeYukle.Text.Trim().Length == 0)
            {
                HataNe += "\nYükleneceği Klasör";
                return false;
            }
            else if (txtKisayolAdi.Text.Trim().Length == 0)
            {
                HataNe += "\nKısayol Adı";
                return false;
            }
            else if (txtProgramVersiyon.Text.Trim().Length == 0)
            {
                HataNe += "\nVersiyon";
                return false;
            }
            else if (txtCopyRight.Text.Trim().Length == 0)
            {
                HataNe += "\nProje Sahibi";
                return false;
            }
            else if (txtDestekText.Text.Trim().Length == 0)
            {
                HataNe += "\nDestek Hattı TEXT";
                return false;
            }
            else if (txtDestekUrl.Text.Trim().Length == 0)
            {
                HataNe += "\nDestek Hattı URL";
                return false;
            }
            else if (txtLisansSozlesmesi.Text.Trim().Length == 0)
            {
                HataNe += "\nLisans Sözleşmesi";
                return false;
            }
            return true;
        }
        public void ProjeyiKaydet() {
            if (ProjeKontrolEtKaydet())
            {
                ProjeNe.ProjeAdi = KodOlustur(comboProje.Text.Trim());
                ProjeNe.ProjeBaslik = txtProjeBaslik.Text.Trim();
                ProjeNe.ProjeKodu = MD5Hash(ProjeNe.ProjeAdi);
                ProjeNe.ProjeMevcutYolu = txtProjeYolu.Text.Trim();
                ProjeNe.ProjeYukleYolu = txtProjeYukle.Text.Trim();
                ProjeNe.ProjeSahibi = txtCopyRight.Text.Trim();
                ProjeNe.ProjeVersiyon = txtProgramVersiyon.Text.Trim();
                ProjeNe.ProjeExeDosya = txtProgramEXE.Text.Trim();
                ProjeNe.ProjeKisayolAdi = txtKisayolAdi.Text.Trim();
                ProjeNe.ProjeWebYolu = txtServerBilgi.Text.Trim();
                ProjeNe.ProjePaketSayisi = txtParcaSayisi.Text.Trim();
                ProjeNe.UreticiAdi = txtDestekText.Text.Trim();
                ProjeNe.UreticiAdres = txtDestekUrl.Text.Trim();
                if (cbDesktop.Checked) ProjeNe.Masaustu = "1"; else ProjeNe.Masaustu = "0";
                if (cbPrograms.Checked) ProjeNe.Programlar = "1"; else ProjeNe.Programlar = "0";
                if (cbStartup.Checked) ProjeNe.Baslangic = "1"; else ProjeNe.Baslangic = "0";
                var IniYaz = new IniSinif(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi +Kur+ @"\Ayarlar.ini");
                IniYaz.Write("ProjeAdi", ProjeNe.ProjeAdi, "PROJE");
                IniYaz.Write("ProjeBaslik", ProjeNe.ProjeBaslik, "PROJE");
                IniYaz.Write("ProjeKodu", ProjeNe.ProjeKodu, "PROJE");
                IniYaz.Write("ProjeMevcutYolu", ProjeNe.ProjeMevcutYolu, "PROJE");
                IniYaz.Write("ProjeYukleYolu", ProjeNe.ProjeYukleYolu, "PROJE");
                IniYaz.Write("ProjeSahibi", ProjeNe.ProjeSahibi, "PROJE");
                IniYaz.Write("ProjeVersiyon", ProjeNe.ProjeVersiyon, "PROJE");
                IniYaz.Write("ProjeExeDosya", ProjeNe.ProjeExeDosya, "PROJE");
                IniYaz.Write("ProjeKisayolAdi", ProjeNe.ProjeKisayolAdi, "PROJE");
                IniYaz.Write("ProjeMasaustu", ProjeNe.Masaustu, "PROJE");
                IniYaz.Write("ProjeProgramlar", ProjeNe.Programlar, "PROJE");
                IniYaz.Write("ProjeBaslangic", ProjeNe.Baslangic, "PROJE");
                IniYaz.Write("ProjePaketSayisi", ProjeNe.ProjePaketSayisi, "PROJE");
                IniYaz.Write("ProjeWebYolu", ProjeNe.ProjeWebYolu, "PROJE");
                IniYaz.Write("DestekText", ProjeNe.UreticiAdi, "PROJE");
                IniYaz.Write("DestekUrl", ProjeNe.UreticiAdres, "PROJE");
                btnProjeKontrol.Enabled = true;
                FileStream yazilacakDosya = new FileStream(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi +Kur+ @"\sozlesme.txt", FileMode.Create); // üzerine ekler.
                //  FileStream yazilacakDosya = new FileStream("d:\\aytac.txt", FileMode.Open); // silbaştan yazar.
                StreamWriter yazici = new StreamWriter(yazilacakDosya, Encoding.UTF8);
                //    yazici.WriteLine(txtLisansSozlesmesi.Text);
                for (int i = 0; i < txtLisansSozlesmesi.Lines.Length; i++)
                {
                    yazici.WriteLine(txtLisansSozlesmesi.Lines[i]);
                }
                yazici.Flush();
                yazici.Close();
                yazilacakDosya.Close();
                lblProjeDurum.Text = "Proje uygunluğunun kontrolü için Proje Uygunluk Kontrol butonuna basılması bekleniyor...";
            }
            else
            {
                MessageBox.Show("Projeniz için gerekli olan bilgiler eksik!\nKontrol Ediniz:\n" + HataNe);
            }
        }
        private void btnProjeKontrol_Click(object sender, EventArgs e)
        {
            if (ProjeKontrolEtUygunluk() && ProjeKontrolEtKaydet())
            {
                if (File.Exists(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + DataTemp + @"\Data1.zip"))
                {
                    btnPaketle.Text = "Mevcut. Yeniden Sıkıştır?";
                }
                btnPaketle.Enabled = true;
                btnExeSec.Enabled = false;
                btnMevcutBul.Enabled = false;
                btnProjeOlustur.Enabled = false;
                btnYukleBul.Enabled = false;
                txtProjeBaslik.Enabled = false;
                txtCopyRight.Enabled = false;
                txtKisayolAdi.Enabled = false;
          //      txtKurulumBilgi.Enabled = false;
                txtProgramEXE.Enabled = false;
                txtProgramVersiyon.Enabled = false;
          //      txtProjeAdi.Enabled = false;
                txtProjeYolu.Enabled = false;
                txtProjeYukle.Enabled = false;
                txtServerBilgi.Enabled = false;
                txtLisansSozlesmesi.Enabled = false;
                txtDestekText.Enabled = false;
                txtDestekUrl.Enabled = false;
                cbDesktop.Enabled = false;
                cbPrograms.Enabled = false;
                cbStartup.Enabled = false;
                lblProjeDurum.Text = "Projenin sıkıştırma işlemi bekleniyor... Sıkıştırma İşlemini Başlat veya Mevcut.Yeniden Sıkıştır butonu bekleniyor...";
                tabControl1.SelectedIndex = 3;
        //        MessageBox.Show("Projeniz için gerekli olan bilgiler eksik!");
            }
            else
            {
                tabControl1.SelectedIndex = 0;
                MessageBox.Show("Projeniz için gerekli olan bilgiler eksik!\nProjenizi gözden geçirin ve PROJE KAYDET tuşuna basarak kaydediniz.");
            }
        }
        private void btnProjeKaydet_Click(object sender, EventArgs e)
        {
            ProjeyiKaydet();
        }
        private void btnParcalamaBaslat_Click(object sender, EventArgs e)
        {
            try
            {
                if (Parcalama == true)
                {
                    btnParcalamaBaslat.Enabled = false;
                    txtParcaSayisi.Enabled = false;
                    if (!Directory.Exists(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + DataWeb))
                    {
                        Directory.CreateDirectory(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + DataWeb);
                    }
                    else
                    {
                        DizinTemizle(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + DataWeb);
                        //  clearFolder(data1);
                    }
                    FileStream inFile = new FileStream(sikismisdosya, FileMode.OpenOrCreate, FileAccess.Read);
                    for (int i = 0; i < x; i++)
                    {
                        FileStream outFile = new FileStream(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + DataWeb + @"\Data1p" + i + ".zip", FileMode.OpenOrCreate, FileAccess.Write);
                        int data = 0;

                        byte[] buffer = new byte[eachSize];
                        if ((data = inFile.Read(buffer, 0, eachSize)) > 0)
                        {
                            outFile.Write(buffer, 0, data);
                        }
                        outFile.Close();
                    }
                    inFile.Close();
                    lblParcaSayisi.Text = "Web parçaları başarıyla hazırlandı!";
                    ProjeNe.ProjePaketSayisi = txtParcaSayisi.Text.Trim();

                }

                ProjeyiKaydet();
                btnProjeyiTamamla.Enabled = true;
                tabControl1.SelectedIndex = 5;
                lblProjeDurum.Text = "Projenin tamamlanması için Proje Tamamla butonu bekleniyor...";
            }
            catch (Exception)
            {
                lblParcaSayisi.Text = "Beklenmeyen bir hata oluştu tekrar deneyiniz!";
            }
        }
        private void KurZipOlustur() {
            string kurzipyolu = string.Empty;
            string kurzipdosyasi = AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + KurZip + @"\Kur.zip";
            if (!Directory.Exists(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + KurZip))
            {
                Directory.CreateDirectory(AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + KurZip);

            }
            kurzipyolu = AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + Kur;
            if (File.Exists(kurzipdosyasi))
            {
                File.Delete(kurzipdosyasi);
            }
            try
            {
                using (ZipFile zip1 = new ZipFile())
                {
                    zip1.AddDirectory(kurzipyolu);
                    zip1.Save(kurzipdosyasi);
                }
                btnTestEt.Enabled = true;
                btnProjeDicGoster.Enabled = true;
                btnZipGoster.Enabled = true;
                btnKurKlasor.Enabled = true;
                btnWebGoster.Enabled = true;
                lblProjeDurum.Text = "Projeniz tamamlandı. TEST Et, Kur Göster, Zip Göster ... gibi butonlara basarak projenizi görebilirsiniz...";
            }
            catch (Exception exc1)
            {
                MessageBox.Show(string.Format("KurZip oluşurken hata oluştu: {0}", exc1.Message));
            }
        
        }
        private void btnYukleBul_Click(object sender, EventArgs e)
        {
            string folderName = this.txtProjeYukle.Text;
            FolderBrowserDialog dlg1 = new FolderBrowserDialog();
            dlg1.SelectedPath = (Directory.Exists(folderName) ? folderName : "c:\\");
            dlg1.ShowNewFolderButton = true;
            DialogResult result = dlg1.ShowDialog();
            if (result == DialogResult.OK)
            {
                ProjeNe.ProjeYukleYolu= dlg1.SelectedPath;
            }
            txtProjeYukle.Text = ProjeNe.ProjeYukleYolu;
            ProjeNe.ProjeYukleYolu = txtProjeYukle.Text.Trim();
        }
        private void btnProjeyiTamamla_Click(object sender, EventArgs e)
        {
            KurZipOlustur();
        }

        private void btnTestEt_Click(object sender, EventArgs e)
        {
            try
            {
                ProcessStartInfo startInfo = new ProcessStartInfo();
                startInfo.FileName = AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + Kur + @"\Kur.exe";
                Process exeProcess = Process.Start(startInfo);
                while (!exeProcess.HasExited)
                {
                    MessageBox.Show("Testin bitmesi bekleniyor...\nVeya Kur programını kapatınız!");
                    Thread.Sleep(5000);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Proje düzgün yapılandırılmadı. Projeyi yeniden düzenleyiniz...\n");
            }
        }

        private void btnKurKlasor_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start("explorer.exe", AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + Kur);
            }
            catch (Exception)
            {
                MessageBox.Show("Proje düzgün yapılandırılmadı. Projeyi yeniden düzenleyiniz...\n");
            }
        }

        private void btnZipGoster_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start("explorer.exe", AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + KurZip);
            }
            catch (Exception)
            {
                MessageBox.Show("Proje düzgün yapılandırılmadı. Projeyi yeniden düzenleyiniz...\n");
            }
        }

        private void btnWebGoster_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start("explorer.exe", AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + DataWeb);
            }
            catch (Exception)
            {
                MessageBox.Show("Proje düzgün yapılandırılmadı. Projeyi yeniden düzenleyiniz...\n");
            }
        }

        private void btnProjeDicGoster_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start("explorer.exe", AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi);
            }
            catch (Exception)
            {
                MessageBox.Show("Proje düzgün yapılandırılmadı. Projeyi yeniden düzenleyiniz...\n");
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (ProjeKontrolEtKaydet())
            {
                            tabControl1.SelectedIndex = 2;
            }
            else
            {
                 tabControl1.SelectedIndex = 0;
                 MessageBox.Show("Bazı bilgileri girmediniz. Projenizi gözden geçiriniz.\n" + HataNe);
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("http://www.aytacsunar.com/AytacWebInstaller");
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            string uploadyolu = AytacWebinstaller + Projeler + @"\" + ProjeNe.ProjeAdi + DataWeb;
            Form1 ac = new Form1();
      //      ac
            ac.uploadyolu = uploadyolu;
            ac.ShowDialog();
            //FtpCredentials frm = new FtpCredentials();
            //frm.ShowDialog();
            //Form1 goster = new Form1();
            //goster.Show();
            //ftpClientCtl1.Host = AytacWebInstaller.Properties.Settings.Default.Host;
            //ftpClientCtl1.Username = AytacWebInstaller.Properties.Settings.Default.Username;
            //ftpClientCtl1.Password = AytacWebInstaller.Properties.Settings.Default.Password;
            //ftpClientCtl1.Populate();
        }
    }
}
