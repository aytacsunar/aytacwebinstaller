﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AytacWebInstaller
{
    public partial class FtpCredentials : Form
    {
        public FtpCredentials()
        {
            InitializeComponent();

            txtHost.Text = AytacWebInstaller.Properties.Settings.Default.Host;
            txtUsername.Text = AytacWebInstaller.Properties.Settings.Default.Username;
            txtPassword.Text = AytacWebInstaller.Properties.Settings.Default.Password;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string host = txtHost.Text;
            if (host.IndexOf("://") < 0) host = "ftp://" + host;
            AytacWebInstaller.Properties.Settings.Default.Host = host;
            AytacWebInstaller.Properties.Settings.Default.Username = txtUsername.Text;
            AytacWebInstaller.Properties.Settings.Default.Password = txtPassword.Text;
            AytacWebInstaller.Properties.Settings.Default.Save();
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void FtpCredentials_Load(object sender, EventArgs e)
        {

        }
    }
}
