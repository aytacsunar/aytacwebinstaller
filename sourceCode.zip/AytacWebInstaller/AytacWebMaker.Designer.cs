﻿namespace AytacWebInstaller
{
    partial class AytacWebMaker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AytacWebMaker));
            this.btnMevcutBul = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtProjeYolu = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtProgramEXE = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnExeSec = new System.Windows.Forms.Button();
            this.txtProgramVersiyon = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCopyRight = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbStartup = new System.Windows.Forms.CheckBox();
            this.cbDesktop = new System.Windows.Forms.CheckBox();
            this.cbPrograms = new System.Windows.Forms.CheckBox();
            this.txtProjeYukle = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtKisayolAdi = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnYukleBul = new System.Windows.Forms.Button();
            this.txtDestekUrl = new System.Windows.Forms.TextBox();
            this.txtDestekText = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnProjeKontrol = new System.Windows.Forms.Button();
            this.comboProje = new System.Windows.Forms.ComboBox();
            this.txtServerBilgi = new System.Windows.Forms.TextBox();
            this.txtProjeBaslik = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btnProjeOlustur = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblSikistirSonra = new System.Windows.Forms.Label();
            this.lblDurum = new System.Windows.Forms.Label();
            this.btnIptal = new System.Windows.Forms.Button();
            this.btnPaketle = new System.Windows.Forms.Button();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnParcalamaBaslat = new System.Windows.Forms.Button();
            this.lblParcaSayisi = new System.Windows.Forms.Label();
            this.txtParcaSayisi = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btnProjeyiTamamla = new System.Windows.Forms.Button();
            this.btnTestEt = new System.Windows.Forms.Button();
            this.btnKurKlasor = new System.Windows.Forms.Button();
            this.btnZipGoster = new System.Windows.Forms.Button();
            this.btnProjeDicGoster = new System.Windows.Forms.Button();
            this.btnWebGoster = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblProjeDurum = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.txtLisansSozlesmesi = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label13 = new System.Windows.Forms.Label();
            this.btnProjeKaydet = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.updateResult = new System.Windows.Forms.Label();
            this.Update_bttn = new System.Windows.Forms.Button();
            this.thisversion = new System.Windows.Forms.TextBox();
            this.versionfilename = new System.Windows.Forms.TextBox();
            this.downloadsurl = new System.Windows.Forms.TextBox();
            this.checkForUpdate_bttn = new System.Windows.Forms.Button();
            this.lblVersiyonNedir = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtProgLisans = new System.Windows.Forms.RichTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnMevcutBul
            // 
            this.btnMevcutBul.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMevcutBul.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnMevcutBul.Enabled = false;
            this.btnMevcutBul.Location = new System.Drawing.Point(396, 6);
            this.btnMevcutBul.Name = "btnMevcutBul";
            this.btnMevcutBul.Size = new System.Drawing.Size(87, 22);
            this.btnMevcutBul.TabIndex = 4;
            this.btnMevcutBul.Text = "Seç";
            this.btnMevcutBul.UseVisualStyleBackColor = false;
            this.btnMevcutBul.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Proje/Program Adı:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(187, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Proje/Program Mevcut Klasörü:";
            // 
            // txtProjeYolu
            // 
            this.txtProjeYolu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtProjeYolu.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtProjeYolu.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
            this.txtProjeYolu.Enabled = false;
            this.txtProjeYolu.Location = new System.Drawing.Point(7, 29);
            this.txtProjeYolu.Name = "txtProjeYolu";
            this.txtProjeYolu.Size = new System.Drawing.Size(476, 21);
            this.txtProjeYolu.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(171, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Proje/Program EXE Dosyası:";
            // 
            // txtProgramEXE
            // 
            this.txtProgramEXE.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtProgramEXE.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtProgramEXE.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystem;
            this.txtProgramEXE.Enabled = false;
            this.txtProgramEXE.Location = new System.Drawing.Point(7, 76);
            this.txtProgramEXE.Name = "txtProgramEXE";
            this.txtProgramEXE.Size = new System.Drawing.Size(476, 21);
            this.txtProgramEXE.TabIndex = 4;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // btnExeSec
            // 
            this.btnExeSec.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExeSec.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnExeSec.Enabled = false;
            this.btnExeSec.Location = new System.Drawing.Point(396, 51);
            this.btnExeSec.Name = "btnExeSec";
            this.btnExeSec.Size = new System.Drawing.Size(87, 22);
            this.btnExeSec.TabIndex = 11;
            this.btnExeSec.Text = "Seç";
            this.btnExeSec.UseVisualStyleBackColor = false;
            this.btnExeSec.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtProgramVersiyon
            // 
            this.txtProgramVersiyon.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtProgramVersiyon.Enabled = false;
            this.txtProgramVersiyon.Location = new System.Drawing.Point(8, 173);
            this.txtProgramVersiyon.Name = "txtProgramVersiyon";
            this.txtProgramVersiyon.Size = new System.Drawing.Size(475, 21);
            this.txtProgramVersiyon.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 157);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(149, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Proje/Program Versiyon:";
            // 
            // txtCopyRight
            // 
            this.txtCopyRight.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCopyRight.Enabled = false;
            this.txtCopyRight.Location = new System.Drawing.Point(7, 173);
            this.txtCopyRight.Name = "txtCopyRight";
            this.txtCopyRight.Size = new System.Drawing.Size(473, 21);
            this.txtCopyRight.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(135, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Proje/Program Sahibi:";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.cbStartup);
            this.groupBox1.Controls.Add(this.cbDesktop);
            this.groupBox1.Controls.Add(this.cbPrograms);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.Location = new System.Drawing.Point(12, 267);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(969, 43);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Kısayol Seçenekleri";
            // 
            // cbStartup
            // 
            this.cbStartup.AutoSize = true;
            this.cbStartup.Enabled = false;
            this.cbStartup.Location = new System.Drawing.Point(483, 19);
            this.cbStartup.Name = "cbStartup";
            this.cbStartup.Size = new System.Drawing.Size(152, 17);
            this.cbStartup.TabIndex = 14;
            this.cbStartup.Text = "Başlangıç (Startup)";
            this.cbStartup.UseVisualStyleBackColor = true;
            // 
            // cbDesktop
            // 
            this.cbDesktop.AutoSize = true;
            this.cbDesktop.Enabled = false;
            this.cbDesktop.Location = new System.Drawing.Point(10, 19);
            this.cbDesktop.Name = "cbDesktop";
            this.cbDesktop.Size = new System.Drawing.Size(156, 17);
            this.cbDesktop.TabIndex = 12;
            this.cbDesktop.Text = "Masaüstü (Desktop)";
            this.cbDesktop.UseVisualStyleBackColor = true;
            // 
            // cbPrograms
            // 
            this.cbPrograms.AutoSize = true;
            this.cbPrograms.Enabled = false;
            this.cbPrograms.Location = new System.Drawing.Point(225, 19);
            this.cbPrograms.Name = "cbPrograms";
            this.cbPrograms.Size = new System.Drawing.Size(179, 17);
            this.cbPrograms.TabIndex = 13;
            this.cbPrograms.Text = "Programlar (Programs)";
            this.cbPrograms.UseVisualStyleBackColor = true;
            // 
            // txtProjeYukle
            // 
            this.txtProjeYukle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtProjeYukle.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtProjeYukle.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
            this.txtProjeYukle.Enabled = false;
            this.txtProjeYukle.Location = new System.Drawing.Point(7, 127);
            this.txtProjeYukle.Name = "txtProjeYukle";
            this.txtProjeYukle.Size = new System.Drawing.Size(476, 21);
            this.txtProjeYukle.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 111);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(208, 13);
            this.label7.TabIndex = 17;
            this.label7.Text = "Proje/Program Yükleneceği Klasör:";
            // 
            // txtKisayolAdi
            // 
            this.txtKisayolAdi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtKisayolAdi.Enabled = false;
            this.txtKisayolAdi.Location = new System.Drawing.Point(7, 127);
            this.txtKisayolAdi.Name = "txtKisayolAdi";
            this.txtKisayolAdi.Size = new System.Drawing.Size(473, 21);
            this.txtKisayolAdi.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 111);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(128, 13);
            this.label8.TabIndex = 19;
            this.label8.Text = "Program Kısayol Adı:";
            // 
            // btnYukleBul
            // 
            this.btnYukleBul.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnYukleBul.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnYukleBul.Enabled = false;
            this.btnYukleBul.Location = new System.Drawing.Point(396, 102);
            this.btnYukleBul.Name = "btnYukleBul";
            this.btnYukleBul.Size = new System.Drawing.Size(87, 22);
            this.btnYukleBul.TabIndex = 32;
            this.btnYukleBul.Text = "Seç";
            this.btnYukleBul.UseVisualStyleBackColor = false;
            this.btnYukleBul.Click += new System.EventHandler(this.btnYukleBul_Click);
            // 
            // txtDestekUrl
            // 
            this.txtDestekUrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDestekUrl.Enabled = false;
            this.txtDestekUrl.Location = new System.Drawing.Point(8, 218);
            this.txtDestekUrl.Name = "txtDestekUrl";
            this.txtDestekUrl.Size = new System.Drawing.Size(475, 21);
            this.txtDestekUrl.TabIndex = 10;
            this.txtDestekUrl.Text = "http://www.aytacsunar.com/AytacWebInstaller";
            // 
            // txtDestekText
            // 
            this.txtDestekText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDestekText.Enabled = false;
            this.txtDestekText.Location = new System.Drawing.Point(7, 218);
            this.txtDestekText.Name = "txtDestekText";
            this.txtDestekText.Size = new System.Drawing.Size(473, 21);
            this.txtDestekText.TabIndex = 9;
            this.txtDestekText.Text = "DESTEK HATTI";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(5, 202);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(153, 13);
            this.label9.TabIndex = 31;
            this.label9.Text = "Üretici Destek Hattı (URL)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 202);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 13);
            this.label1.TabIndex = 30;
            this.label1.Text = "Üretici Destek Hattı (TEXT)";
            // 
            // btnProjeKontrol
            // 
            this.btnProjeKontrol.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnProjeKontrol.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnProjeKontrol.Enabled = false;
            this.btnProjeKontrol.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnProjeKontrol.Location = new System.Drawing.Point(289, 179);
            this.btnProjeKontrol.Name = "btnProjeKontrol";
            this.btnProjeKontrol.Size = new System.Drawing.Size(403, 32);
            this.btnProjeKontrol.TabIndex = 16;
            this.btnProjeKontrol.Text = "Proje Uygunluk Kontrol >>>";
            this.btnProjeKontrol.UseVisualStyleBackColor = false;
            this.btnProjeKontrol.Click += new System.EventHandler(this.btnProjeKontrol_Click);
            // 
            // comboProje
            // 
            this.comboProje.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboProje.BackColor = System.Drawing.Color.White;
            this.comboProje.FormattingEnabled = true;
            this.comboProje.Location = new System.Drawing.Point(7, 29);
            this.comboProje.Name = "comboProje";
            this.comboProje.Size = new System.Drawing.Size(473, 21);
            this.comboProje.TabIndex = 1;
            this.comboProje.DropDownClosed += new System.EventHandler(this.comboProje_DropDownClosed);
            // 
            // txtServerBilgi
            // 
            this.txtServerBilgi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtServerBilgi.Enabled = false;
            this.txtServerBilgi.Location = new System.Drawing.Point(62, 343);
            this.txtServerBilgi.Name = "txtServerBilgi";
            this.txtServerBilgi.Size = new System.Drawing.Size(919, 21);
            this.txtServerBilgi.TabIndex = 11;
            // 
            // txtProjeBaslik
            // 
            this.txtProjeBaslik.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtProjeBaslik.Enabled = false;
            this.txtProjeBaslik.Location = new System.Drawing.Point(7, 76);
            this.txtProjeBaslik.Name = "txtProjeBaslik";
            this.txtProjeBaslik.Size = new System.Drawing.Size(473, 21);
            this.txtProjeBaslik.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 322);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(167, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Proje Web Yolu (WEBPART):";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 60);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(164, 13);
            this.label10.TabIndex = 22;
            this.label10.Text = "Projenin/Programın Başlığı:";
            // 
            // btnProjeOlustur
            // 
            this.btnProjeOlustur.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnProjeOlustur.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnProjeOlustur.Location = new System.Drawing.Point(323, 6);
            this.btnProjeOlustur.Name = "btnProjeOlustur";
            this.btnProjeOlustur.Size = new System.Drawing.Size(157, 22);
            this.btnProjeOlustur.TabIndex = 21;
            this.btnProjeOlustur.Text = "Proje Aç / Yeni Proje";
            this.btnProjeOlustur.UseVisualStyleBackColor = false;
            this.btnProjeOlustur.Click += new System.EventHandler(this.btnProjeOlustur_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.lblSikistirSonra);
            this.groupBox3.Controls.Add(this.lblDurum);
            this.groupBox3.Controls.Add(this.btnIptal);
            this.groupBox3.Controls.Add(this.btnPaketle);
            this.groupBox3.Controls.Add(this.progressBar2);
            this.groupBox3.Controls.Add(this.progressBar1);
            this.groupBox3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(983, 121);
            this.groupBox3.TabIndex = 26;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "PROJE DOSYALARININ SIKIŞTIRILMASI";
            // 
            // lblSikistirSonra
            // 
            this.lblSikistirSonra.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSikistirSonra.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblSikistirSonra.Location = new System.Drawing.Point(7, 84);
            this.lblSikistirSonra.Name = "lblSikistirSonra";
            this.lblSikistirSonra.Size = new System.Drawing.Size(970, 13);
            this.lblSikistirSonra.TabIndex = 5;
            this.lblSikistirSonra.Text = "...";
            // 
            // lblDurum
            // 
            this.lblDurum.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDurum.Location = new System.Drawing.Point(7, 61);
            this.lblDurum.Name = "lblDurum";
            this.lblDurum.Size = new System.Drawing.Size(663, 13);
            this.lblDurum.TabIndex = 4;
            this.lblDurum.Text = "...";
            // 
            // btnIptal
            // 
            this.btnIptal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnIptal.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnIptal.Enabled = false;
            this.btnIptal.Location = new System.Drawing.Point(677, 61);
            this.btnIptal.Name = "btnIptal";
            this.btnIptal.Size = new System.Drawing.Size(87, 22);
            this.btnIptal.TabIndex = 3;
            this.btnIptal.Text = "İptal";
            this.btnIptal.UseVisualStyleBackColor = false;
            this.btnIptal.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnPaketle
            // 
            this.btnPaketle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPaketle.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnPaketle.Enabled = false;
            this.btnPaketle.Location = new System.Drawing.Point(772, 61);
            this.btnPaketle.Name = "btnPaketle";
            this.btnPaketle.Size = new System.Drawing.Size(205, 22);
            this.btnPaketle.TabIndex = 17;
            this.btnPaketle.Text = "Sıkıştırma İşlemini Başlat!";
            this.btnPaketle.UseVisualStyleBackColor = false;
            this.btnPaketle.Click += new System.EventHandler(this.btnPaketle_Click);
            // 
            // progressBar2
            // 
            this.progressBar2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar2.Location = new System.Drawing.Point(10, 40);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(967, 15);
            this.progressBar2.TabIndex = 1;
            // 
            // progressBar1
            // 
            this.progressBar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar1.Location = new System.Drawing.Point(10, 19);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(967, 15);
            this.progressBar1.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.btnParcalamaBaslat);
            this.groupBox4.Controls.Add(this.lblParcaSayisi);
            this.groupBox4.Controls.Add(this.txtParcaSayisi);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox4.Location = new System.Drawing.Point(3, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(983, 102);
            this.groupBox4.TabIndex = 27;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "PROJE WEB PARÇALARIN HAZIRLANMASI";
            // 
            // btnParcalamaBaslat
            // 
            this.btnParcalamaBaslat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnParcalamaBaslat.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnParcalamaBaslat.Enabled = false;
            this.btnParcalamaBaslat.Location = new System.Drawing.Point(724, 61);
            this.btnParcalamaBaslat.Name = "btnParcalamaBaslat";
            this.btnParcalamaBaslat.Size = new System.Drawing.Size(253, 22);
            this.btnParcalamaBaslat.TabIndex = 19;
            this.btnParcalamaBaslat.Text = "Parçalama İşlemini Başlat!";
            this.btnParcalamaBaslat.UseVisualStyleBackColor = false;
            this.btnParcalamaBaslat.Click += new System.EventHandler(this.btnParcalamaBaslat_Click);
            // 
            // lblParcaSayisi
            // 
            this.lblParcaSayisi.AutoSize = true;
            this.lblParcaSayisi.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblParcaSayisi.Location = new System.Drawing.Point(10, 44);
            this.lblParcaSayisi.Name = "lblParcaSayisi";
            this.lblParcaSayisi.Size = new System.Drawing.Size(162, 13);
            this.lblParcaSayisi.TabIndex = 29;
            this.lblParcaSayisi.Text = "Parça sayısını belirleyiniz...";
            // 
            // txtParcaSayisi
            // 
            this.txtParcaSayisi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtParcaSayisi.Enabled = false;
            this.txtParcaSayisi.Location = new System.Drawing.Point(171, 16);
            this.txtParcaSayisi.Name = "txtParcaSayisi";
            this.txtParcaSayisi.Size = new System.Drawing.Size(806, 21);
            this.txtParcaSayisi.TabIndex = 18;
            this.txtParcaSayisi.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(10, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(132, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "Parça Sayısını Giriniz:";
            // 
            // btnProjeyiTamamla
            // 
            this.btnProjeyiTamamla.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnProjeyiTamamla.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnProjeyiTamamla.Enabled = false;
            this.btnProjeyiTamamla.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnProjeyiTamamla.ForeColor = System.Drawing.Color.Black;
            this.btnProjeyiTamamla.Location = new System.Drawing.Point(381, 55);
            this.btnProjeyiTamamla.Name = "btnProjeyiTamamla";
            this.btnProjeyiTamamla.Size = new System.Drawing.Size(223, 37);
            this.btnProjeyiTamamla.TabIndex = 29;
            this.btnProjeyiTamamla.Text = "Projeyi TAMAMLA >>";
            this.btnProjeyiTamamla.UseVisualStyleBackColor = false;
            this.btnProjeyiTamamla.Click += new System.EventHandler(this.btnProjeyiTamamla_Click);
            // 
            // btnTestEt
            // 
            this.btnTestEt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTestEt.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnTestEt.Enabled = false;
            this.btnTestEt.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnTestEt.ForeColor = System.Drawing.Color.Black;
            this.btnTestEt.Location = new System.Drawing.Point(381, 121);
            this.btnTestEt.Name = "btnTestEt";
            this.btnTestEt.Size = new System.Drawing.Size(223, 37);
            this.btnTestEt.TabIndex = 30;
            this.btnTestEt.Text = "TEST ET!";
            this.btnTestEt.UseVisualStyleBackColor = false;
            this.btnTestEt.Click += new System.EventHandler(this.btnTestEt_Click);
            // 
            // btnKurKlasor
            // 
            this.btnKurKlasor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnKurKlasor.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnKurKlasor.Enabled = false;
            this.btnKurKlasor.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKurKlasor.ForeColor = System.Drawing.Color.Black;
            this.btnKurKlasor.Location = new System.Drawing.Point(381, 164);
            this.btnKurKlasor.Name = "btnKurKlasor";
            this.btnKurKlasor.Size = new System.Drawing.Size(223, 37);
            this.btnKurKlasor.TabIndex = 31;
            this.btnKurKlasor.Text = "Kur Göster";
            this.btnKurKlasor.UseVisualStyleBackColor = false;
            this.btnKurKlasor.Click += new System.EventHandler(this.btnKurKlasor_Click);
            // 
            // btnZipGoster
            // 
            this.btnZipGoster.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnZipGoster.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnZipGoster.Enabled = false;
            this.btnZipGoster.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnZipGoster.ForeColor = System.Drawing.Color.Black;
            this.btnZipGoster.Location = new System.Drawing.Point(381, 207);
            this.btnZipGoster.Name = "btnZipGoster";
            this.btnZipGoster.Size = new System.Drawing.Size(223, 37);
            this.btnZipGoster.TabIndex = 32;
            this.btnZipGoster.Text = "Zip Göster";
            this.btnZipGoster.UseVisualStyleBackColor = false;
            this.btnZipGoster.Click += new System.EventHandler(this.btnZipGoster_Click);
            // 
            // btnProjeDicGoster
            // 
            this.btnProjeDicGoster.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnProjeDicGoster.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnProjeDicGoster.Enabled = false;
            this.btnProjeDicGoster.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnProjeDicGoster.ForeColor = System.Drawing.Color.Black;
            this.btnProjeDicGoster.Location = new System.Drawing.Point(381, 293);
            this.btnProjeDicGoster.Name = "btnProjeDicGoster";
            this.btnProjeDicGoster.Size = new System.Drawing.Size(223, 37);
            this.btnProjeDicGoster.TabIndex = 33;
            this.btnProjeDicGoster.Text = "Proje Klasörünü Göster";
            this.btnProjeDicGoster.UseVisualStyleBackColor = false;
            this.btnProjeDicGoster.Click += new System.EventHandler(this.btnProjeDicGoster_Click);
            // 
            // btnWebGoster
            // 
            this.btnWebGoster.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnWebGoster.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnWebGoster.Enabled = false;
            this.btnWebGoster.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnWebGoster.ForeColor = System.Drawing.Color.Black;
            this.btnWebGoster.Location = new System.Drawing.Point(381, 250);
            this.btnWebGoster.Name = "btnWebGoster";
            this.btnWebGoster.Size = new System.Drawing.Size(223, 37);
            this.btnWebGoster.TabIndex = 34;
            this.btnWebGoster.Text = "Web Göster";
            this.btnWebGoster.UseVisualStyleBackColor = false;
            this.btnWebGoster.Click += new System.EventHandler(this.btnWebGoster_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.Green;
            this.panel1.Controls.Add(this.lblProjeDurum);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Location = new System.Drawing.Point(-5, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1221, 31);
            this.panel1.TabIndex = 35;
            // 
            // lblProjeDurum
            // 
            this.lblProjeDurum.AutoSize = true;
            this.lblProjeDurum.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblProjeDurum.ForeColor = System.Drawing.Color.White;
            this.lblProjeDurum.Location = new System.Drawing.Point(134, 7);
            this.lblProjeDurum.Name = "lblProjeDurum";
            this.lblProjeDurum.Size = new System.Drawing.Size(425, 16);
            this.lblProjeDurum.TabIndex = 1;
            this.lblProjeDurum.Text = "Proje açılması veya yeni proje oluşturulması bekleniyor...";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(14, 7);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(123, 16);
            this.label14.TabIndex = 0;
            this.label14.Text = "PROJE DURUMU:";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.txtProjeBaslik);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.txtDestekText);
            this.panel2.Controls.Add(this.btnProjeOlustur);
            this.panel2.Controls.Add(this.comboProje);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.txtCopyRight);
            this.panel2.Controls.Add(this.txtKisayolAdi);
            this.panel2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(486, 248);
            this.panel2.TabIndex = 36;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.btnYukleBul);
            this.panel3.Controls.Add(this.btnMevcutBul);
            this.panel3.Controls.Add(this.txtDestekUrl);
            this.panel3.Controls.Add(this.txtProgramEXE);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.txtProjeYolu);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.btnExeSec);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.txtProjeYukle);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.txtProgramVersiyon);
            this.panel3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel3.Location = new System.Drawing.Point(495, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(486, 248);
            this.panel3.TabIndex = 37;
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.txtLisansSozlesmesi);
            this.groupBox5.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox5.Location = new System.Drawing.Point(9, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(975, 397);
            this.groupBox5.TabIndex = 28;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "LİSANS ve KURULUM SÖZLEŞMESİ";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.button1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(799, 359);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(170, 32);
            this.button1.TabIndex = 16;
            this.button1.Text = ">>>";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // txtLisansSozlesmesi
            // 
            this.txtLisansSozlesmesi.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLisansSozlesmesi.Enabled = false;
            this.txtLisansSozlesmesi.Location = new System.Drawing.Point(6, 20);
            this.txtLisansSozlesmesi.Name = "txtLisansSozlesmesi";
            this.txtLisansSozlesmesi.Size = new System.Drawing.Size(963, 333);
            this.txtLisansSozlesmesi.TabIndex = 0;
            this.txtLisansSozlesmesi.Text = "";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.panel3, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 6);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 255F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(984, 255);
            this.tableLayoutPanel3.TabIndex = 29;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.Location = new System.Drawing.Point(10, 346);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 16);
            this.label13.TabIndex = 4;
            this.label13.Text = "http://";
            // 
            // btnProjeKaydet
            // 
            this.btnProjeKaydet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnProjeKaydet.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnProjeKaydet.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnProjeKaydet.Location = new System.Drawing.Point(372, 116);
            this.btnProjeKaydet.Name = "btnProjeKaydet";
            this.btnProjeKaydet.Size = new System.Drawing.Size(251, 32);
            this.btnProjeKaydet.TabIndex = 15;
            this.btnProjeKaydet.Text = "Projeyi Kaydet";
            this.btnProjeKaydet.UseVisualStyleBackColor = false;
            this.btnProjeKaydet.Click += new System.EventHandler(this.btnProjeKaydet_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Location = new System.Drawing.Point(12, 36);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(998, 435);
            this.tabControl1.TabIndex = 43;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.tableLayoutPanel3);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.txtServerBilgi);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(990, 409);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "1-) Proje Bilgileri";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.BackColor = System.Drawing.Color.LightSteelBlue;
            this.button2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.Location = new System.Drawing.Point(811, 371);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(170, 32);
            this.button2.TabIndex = 30;
            this.button2.Text = ">>>";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(990, 409);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "2-) Lisans Sözleşmesi";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.btnProjeKaydet);
            this.tabPage6.Controls.Add(this.btnProjeKontrol);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(990, 409);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "3-) Proje Kayıt ve Kontrol";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(990, 409);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "4-) Dosyaların Sıkıştırılması";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox2);
            this.tabPage4.Controls.Add(this.groupBox4);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(990, 409);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "5-) Web Parçaların Hazırlanması";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Location = new System.Drawing.Point(4, 112);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(982, 67);
            this.groupBox2.TabIndex = 29;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "FTP Gezgini ile DOSYALARI YÜKLEYİN!";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.LightSteelBlue;
            this.button3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button3.Location = new System.Drawing.Point(324, 20);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(336, 29);
            this.button3.TabIndex = 28;
            this.button3.Text = "FTP GEZGİNİNİ AÇ!";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.btnTestEt);
            this.tabPage5.Controls.Add(this.btnProjeyiTamamla);
            this.tabPage5.Controls.Add(this.btnKurKlasor);
            this.tabPage5.Controls.Add(this.btnProjeDicGoster);
            this.tabPage5.Controls.Add(this.btnZipGoster);
            this.tabPage5.Controls.Add(this.btnWebGoster);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(990, 409);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "6-) Sonuç";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.updateResult);
            this.tabPage7.Controls.Add(this.Update_bttn);
            this.tabPage7.Controls.Add(this.thisversion);
            this.tabPage7.Controls.Add(this.versionfilename);
            this.tabPage7.Controls.Add(this.downloadsurl);
            this.tabPage7.Controls.Add(this.checkForUpdate_bttn);
            this.tabPage7.Controls.Add(this.lblVersiyonNedir);
            this.tabPage7.Controls.Add(this.linkLabel1);
            this.tabPage7.Controls.Add(this.panel5);
            this.tabPage7.Controls.Add(this.txtProgLisans);
            this.tabPage7.Controls.Add(this.label18);
            this.tabPage7.Controls.Add(this.label17);
            this.tabPage7.Controls.Add(this.label16);
            this.tabPage7.Controls.Add(this.label15);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(990, 409);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Hakkında/Yardım";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // updateResult
            // 
            this.updateResult.AutoSize = true;
            this.updateResult.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.updateResult.ForeColor = System.Drawing.Color.Red;
            this.updateResult.Location = new System.Drawing.Point(526, 94);
            this.updateResult.Name = "updateResult";
            this.updateResult.Size = new System.Drawing.Size(263, 13);
            this.updateResult.TabIndex = 14;
            this.updateResult.Text = "Güncelleştirme başarıyla tamamlandı...";
            // 
            // Update_bttn
            // 
            this.Update_bttn.Location = new System.Drawing.Point(780, 62);
            this.Update_bttn.Name = "Update_bttn";
            this.Update_bttn.Size = new System.Drawing.Size(207, 23);
            this.Update_bttn.TabIndex = 13;
            this.Update_bttn.Text = "Güncelleştir...";
            this.Update_bttn.UseVisualStyleBackColor = true;
            this.Update_bttn.Click += new System.EventHandler(this.update_bttn_Click);
            // 
            // thisversion
            // 
            this.thisversion.Location = new System.Drawing.Point(529, 64);
            this.thisversion.Name = "thisversion";
            this.thisversion.Size = new System.Drawing.Size(158, 21);
            this.thisversion.TabIndex = 12;
            // 
            // versionfilename
            // 
            this.versionfilename.Location = new System.Drawing.Point(529, 35);
            this.versionfilename.Name = "versionfilename";
            this.versionfilename.Size = new System.Drawing.Size(458, 21);
            this.versionfilename.TabIndex = 11;
            this.versionfilename.Text = "guncelleme.txt";
            // 
            // downloadsurl
            // 
            this.downloadsurl.Location = new System.Drawing.Point(529, 7);
            this.downloadsurl.Name = "downloadsurl";
            this.downloadsurl.Size = new System.Drawing.Size(458, 21);
            this.downloadsurl.TabIndex = 10;
            this.downloadsurl.Text = "http://www.aytacsunar.com/AytacWebInstaller/Kur/Update/";
            // 
            // checkForUpdate_bttn
            // 
            this.checkForUpdate_bttn.Location = new System.Drawing.Point(315, 19);
            this.checkForUpdate_bttn.Name = "checkForUpdate_bttn";
            this.checkForUpdate_bttn.Size = new System.Drawing.Size(207, 23);
            this.checkForUpdate_bttn.TabIndex = 9;
            this.checkForUpdate_bttn.Text = "Güncellemeleri Kontrol Et!";
            this.checkForUpdate_bttn.UseVisualStyleBackColor = true;
            this.checkForUpdate_bttn.Click += new System.EventHandler(this.checkForUpdate_bttn_Click);
            // 
            // lblVersiyonNedir
            // 
            this.lblVersiyonNedir.AutoSize = true;
            this.lblVersiyonNedir.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblVersiyonNedir.Location = new System.Drawing.Point(246, 22);
            this.lblVersiyonNedir.Name = "lblVersiyonNedir";
            this.lblVersiyonNedir.Size = new System.Drawing.Size(63, 16);
            this.lblVersiyonNedir.TabIndex = 8;
            this.lblVersiyonNedir.Text = "Versiyon";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(171, 72);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(235, 13);
            this.linkLabel1.TabIndex = 7;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "www.aytacsunar.com/AytacWebInstaller";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // panel5
            // 
            this.panel5.BackgroundImage = global::AytacWebInstaller.Properties.Resources.imageedit_1_2851547133;
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel5.Location = new System.Drawing.Point(3, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(103, 101);
            this.panel5.TabIndex = 6;
            // 
            // txtProgLisans
            // 
            this.txtProgLisans.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtProgLisans.Location = new System.Drawing.Point(3, 110);
            this.txtProgLisans.Name = "txtProgLisans";
            this.txtProgLisans.Size = new System.Drawing.Size(984, 296);
            this.txtProgLisans.TabIndex = 4;
            this.txtProgLisans.Text = "";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.Location = new System.Drawing.Point(112, 70);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(62, 16);
            this.label18.TabIndex = 3;
            this.label18.Text = "Dağıtım:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.Location = new System.Drawing.Point(112, 54);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 16);
            this.label17.TabIndex = 2;
            this.label17.Text = "Aytaç Sunar";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.Location = new System.Drawing.Point(112, 38);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(134, 16);
            this.label16.TabIndex = 1;
            this.label16.Text = "Telif Hakkı  © 2014";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.Location = new System.Drawing.Point(112, 22);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(128, 16);
            this.label15.TabIndex = 0;
            this.label15.Text = "AytacWebInstaller";
            // 
            // AytacWebMaker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1017, 483);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AytacWebMaker";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AytacWebInstaller";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMevcutBul;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox txtProjeYolu;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox txtProgramEXE;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnExeSec;
        public System.Windows.Forms.TextBox txtProgramVersiyon;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox txtCopyRight;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox cbDesktop;
        private System.Windows.Forms.CheckBox cbStartup;
        private System.Windows.Forms.CheckBox cbPrograms;
        public System.Windows.Forms.TextBox txtProjeYukle;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.TextBox txtKisayolAdi;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnProjeOlustur;
        public System.Windows.Forms.TextBox txtProjeBaslik;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboProje;
        private System.Windows.Forms.Button btnProjeKontrol;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button btnPaketle;
        private System.Windows.Forms.Button btnIptal;
        private System.Windows.Forms.Label lblDurum;
        private System.Windows.Forms.Label lblSikistirSonra;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtParcaSayisi;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblParcaSayisi;
        private System.Windows.Forms.Button btnParcalamaBaslat;
        private System.Windows.Forms.TextBox txtServerBilgi;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtDestekUrl;
        private System.Windows.Forms.TextBox txtDestekText;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnYukleBul;
        private System.Windows.Forms.Button btnProjeyiTamamla;
        private System.Windows.Forms.Button btnTestEt;
        private System.Windows.Forms.Button btnKurKlasor;
        private System.Windows.Forms.Button btnZipGoster;
        private System.Windows.Forms.Button btnProjeDicGoster;
        private System.Windows.Forms.Button btnWebGoster;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RichTextBox txtLisansSozlesmesi;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnProjeKaydet;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblProjeDurum;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.RichTextBox txtProgLisans;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label lblVersiyonNedir;
        private System.Windows.Forms.Button checkForUpdate_bttn;
        private System.Windows.Forms.TextBox thisversion;
        private System.Windows.Forms.TextBox versionfilename;
        private System.Windows.Forms.TextBox downloadsurl;
        private System.Windows.Forms.Button Update_bttn;
        private System.Windows.Forms.Label updateResult;
        private System.Windows.Forms.Button button3;
        public AytacWebInstaller.FtpClientCtl ftpClientCtl1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}

