﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Net;
using System.Diagnostics;
using System.Threading;
using Microsoft.Win32;
using System.Text;
using System.Windows.Forms;
using IWshRuntimeLibrary;
using Ionic.Zip;
using Ionic.Zlib;
using System.Runtime;
using System.Runtime.InteropServices;

namespace Kur
{
    public partial class WebKur : Form
    {
        [DllImport("wininet.dll")]
        private extern static bool InternetGetConnectedState(out int Aciklama, int Rezerve);
        public class ProgramTemel
        {
            public string ProjeAdi { get; set; }
            public string ProjeBaslik { get; set; }
            public string ProjeMevcutYolu { get; set; }
            public string ProjeYukleYolu { get; set; }
            public string ProjeKodu { get; set; }
            public string PaketAdi { get; set; }
            public string ProjePaketSayisi { get; set; }
            public string ProjeSahibi { get; set; }
            public string ProjeExeDosya { get; set; }
            public string ProjeVersiyon { get; set; }
            public string ProjeKisayolAdi { get; set; }
            public string ProjeWebYolu { get; set; }
            public string ProjeKaynakKlasor { get; set; }
            public string ProjeBulunduguYer { get; set; }
            public string ProjeYuklenenYer { get; set; }
            public string ToplamPaket { get; set; }
            public string Masaustu { get; set; }
            public string Baslangic { get; set; }
            public string Programlar { get; set; }
            public string UreticiAdi { get; set; }
            public string UreticiAdres { get; set; }
        }
        string kaynakklasor = string.Empty;
        string bulunduguyer = Application.StartupPath;
        int yenidenyukleme = 0;
        string yuklenenyer = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\AytacWebInstaller\Projeler\";
        string data1 = @"c:\";
        int indirmeislemiaktif = 0;
        string islemhaberi = string.Empty;
        int kuradet = 0;
        long inenboyut = 0;
        int KurulumTuru = 0;
        int toplampaket = 0;
        int mevcutpaket = 0;
        private byte[] downloadedData;
        List<icerik> dosyalar = new List<icerik>();
        List<icerik> linkler = new List<icerik>();
        List<icerik> dosyaparcasi = new List<icerik>();
        List<icerik> hatalar = new List<icerik>();
        ProgramTemel ProjeNe = new ProgramTemel();
        public WebKur()
        {
            InitializeComponent();
        }
        private const int CP_NOCLOSE_BUTTON = 0x200;
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams myCp = base.CreateParams;
                myCp.ClassStyle = myCp.ClassStyle | CP_NOCLOSE_BUTTON;
                return myCp;
            }
        }
        public bool ProjeKontrolEtUygunluk()
        {
            if (ProjeNe.ProjeYukleYolu.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.ProjeMevcutYolu.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.ProjeSahibi.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.ProjeVersiyon.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.ProjeExeDosya.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.ProjeAdi.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.ProjeBaslik.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.ProjeKisayolAdi.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.UreticiAdi.Length == 0)
            {
                return false;
            }
            else if (ProjeNe.UreticiAdres.Length == 0)
            {
                return false;
            }
            return true;
        }
        private void Yukle_Load(object sender, EventArgs e)
        {
            FileInfo sozlesme = new FileInfo(bulunduguyer + @"\sozlesme.txt");
            if (sozlesme.Exists)
            {
                StreamReader okuyucu = new StreamReader(bulunduguyer + @"\sozlesme.txt");
                richTextBox1.Text = okuyucu.ReadToEnd();
                okuyucu.Close();
            }
            else
            {
                richTextBox1.Text = "Uygulama bilgisayarınıza yüklenecektir.";
            }
            FileInfo Bulini = new FileInfo(bulunduguyer + @"\Ayarlar.ini");
            if (Bulini.Exists)
            {
                var IniOku = new IniSinif(bulunduguyer + @"\Ayarlar.ini");
                var iniProjeAdi = IniOku.Read("ProjeAdi", "PROJE");
                var iniProjeBaslik = IniOku.Read("ProjeBaslik", "PROJE");
                var iniProjeKodu = IniOku.Read("ProjeKodu", "PROJE");
                var iniProjeMevcutYolu = IniOku.Read("ProjeMevcutYolu", "PROJE");
                var iniProjeYukleYolu = IniOku.Read("ProjeYukleYolu", "PROJE");
                var iniProjeSahibi = IniOku.Read("ProjeSahibi", "PROJE");
                var iniProjeVersiyon = IniOku.Read("ProjeVersiyon", "PROJE");
                var iniProjeExeDosya = IniOku.Read("ProjeExeDosya", "PROJE");
                var iniKisayolAdi = IniOku.Read("ProjeKisayolAdi", "PROJE");
                var iniProjeMasaustu = IniOku.Read("ProjeMasaustu", "PROJE");
                var iniProjeProgramlar = IniOku.Read("ProjeProgramlar", "PROJE");
                var iniProjeBaslangic = IniOku.Read("ProjeBaslangic", "PROJE");
                var iniProjePaketSayisi = IniOku.Read("ProjePaketSayisi", "PROJE");
                var iniProjeWebYolu = IniOku.Read("ProjeWebYolu", "PROJE");
                var iniDestekText = IniOku.Read("DestekText", "PROJE");
                var iniDestekUrl = IniOku.Read("DestekUrl", "PROJE");
                ProjeNe.ProjeAdi = iniProjeAdi.ToString();
                ProjeNe.ProjeBaslik = iniProjeBaslik.ToString();
                ProjeNe.ProjeKodu = iniProjeKodu.ToString();
                ProjeNe.ProjeMevcutYolu = iniProjeMevcutYolu.ToString();
                ProjeNe.ProjeYukleYolu = iniProjeYukleYolu.ToString();
                ProjeNe.ProjeSahibi = iniProjeSahibi.ToString();
                ProjeNe.ProjeVersiyon = iniProjeVersiyon.ToString();
                ProjeNe.ProjeExeDosya = iniProjeExeDosya.ToString();
                ProjeNe.ProjeKisayolAdi = iniKisayolAdi.ToString();
                ProjeNe.Masaustu = iniProjeMasaustu.ToString();
                ProjeNe.Programlar = iniProjeProgramlar.ToString();
                ProjeNe.Baslangic = iniProjeBaslangic.ToString();
                ProjeNe.ProjePaketSayisi = iniProjePaketSayisi.ToString();
                ProjeNe.ProjeWebYolu = iniProjeWebYolu.ToString();
                ProjeNe.UreticiAdi = iniDestekText.ToString();
                ProjeNe.UreticiAdres = iniDestekUrl.ToString();
                if (ProjeKontrolEtUygunluk())
                {
                    yuklenenyer = yuklenenyer + @"\" + ProjeNe.ProjeKodu;
                    data1 = ProjeNe.ProjeYukleYolu;
                    progressBar2.Maximum = Convert.ToInt32(ProjeNe.ProjePaketSayisi) + 200;
                    progressBar2.Value = Convert.ToInt32(ProjeNe.ProjePaketSayisi) + 200;
                    this.Text = ProjeNe.ProjeBaslik + " (AytacWebInstaller)";
                    linkLabel1.Text = ProjeNe.UreticiAdi;
                    lblKurulumAdi.Text = ProjeNe.ProjeBaslik;
                    Kontrol();
                    label3.Text = islemhaberi;
                }
                else
                {
                    MessageBox.Show("Kurulum için gerekli sistem dosyasında eksiklik/yanlışlık bulundu. Lütfen üreticiyle iletişime geçiniz.");
                    button1.Enabled = false;
                    button1.Text = "KAPAT";
                    checkBox1.Enabled = false;
                    label3.Text = "Kurulum için gerekli sistem dosyasında eksiklik/yanlışlık bulundu. Lütfen üreticiyle iletişime geçiniz.";
                    button2.Text = "KAPAT";
                }

            }
            else
            {
                MessageBox.Show("Kurulum için gerekli sistem dosyası bulunmadı. Lütfen üreticiyle iletişime geçiniz.");
                button1.Enabled = false;
                button1.Text = "KAPAT";
                checkBox1.Enabled = false;
                label3.Text = "Kurulumun başlaması için gerekli dosyalar bulunamadı. Lütfen üreticiyle iletişime geçiniz.";
                button2.Text = "KAPAT";
            }
            progressBar2.Step = 1;
            //    progressBar2.Value = 0;
            progressBar1.Maximum = 100;
            progressBar1.Step = 1;
        }
        private void Kontrol()
        {
            dosyalar.Clear();
            dosyaparcasi.Clear();
            kuradet = 0;
            FileInfo DataKontrol = new FileInfo(bulunduguyer + @"\Data1.zip");
            if (DataKontrol.Exists)
            {
                kuradet++;
            }
            if (kuradet < 1)
            {
                kuradet = 0;
                FileInfo TheFile = new FileInfo(yuklenenyer + @"\Data1.zip");
                if (TheFile.Exists)
                {
                    kuradet++;
                }
                if (kuradet < 1)
                {
                    checkBox1.Checked = true;
                    checkBox1.Enabled = false;
                    kaynakklasor = yuklenenyer;
                    button1.Text = "İNDİR";
                    button1.Enabled = true;
                    if (!Directory.Exists(yuklenenyer))
                    {
                        Directory.CreateDirectory(yuklenenyer);
                    }
                    for (int y = 0; y < Convert.ToInt32(ProjeNe.ProjePaketSayisi); y++)
                    {
                        icerik yeni = new icerik();
                        yeni.degeri = ProjeNe.ProjeWebYolu + @"/Data1p" + y + ".zip";
                        yeni.dosyaadi = "Data1p" + y + ".zip";
                        yeni.sirano = y;
                        dosyalar.Add(yeni);
                    }
                    foreach (icerik item in dosyalar)
                    {
                        FileInfo DataPart = new FileInfo(bulunduguyer + @"\" + item.dosyaadi);
                        if (!DataPart.Exists)
                        {
                            dosyaparcasi.Add(item);
                        }
                    }
                    if (dosyaparcasi.Count == 0)
                    {
                        kaynakklasor = bulunduguyer;
                    }
                    else
                    {
                        if (dosyaparcasi.Count != dosyalar.Count)
                        {
                            kaynakklasor = bulunduguyer;
                        }
                        else
                        {
                            kaynakklasor = yuklenenyer;
                        }
                        dosyalar.Clear();
                        dosyaparcasi.Clear();
                        for (int y = 0; y < Convert.ToInt32(ProjeNe.ProjePaketSayisi); y++)
                        {
                            icerik yeni = new icerik();
                            yeni.degeri = ProjeNe.ProjeWebYolu + @"/Data1p" + y + ".zip";
                            yeni.dosyaadi = "Data1p" + y + ".zip";
                            yeni.sirano = y;
                            dosyalar.Add(yeni);
                        }
                        foreach (icerik item in dosyalar)
                        {
                            FileInfo DataPart = new FileInfo(kaynakklasor + @"\" + item.dosyaadi);
                            if (!DataPart.Exists)
                            {
                                dosyaparcasi.Add(item);
                            }
                        }
                    }
                    toplampaket = dosyalar.Count;
                    mevcutpaket = toplampaket - dosyaparcasi.Count;
                    if (dosyaparcasi.Count == 0)
                    {
                        button1.Text = ProjeNe.ProjeBaslik + " YÜKLE";
                        checkBox1.Checked = false;
                        islemhaberi = "Tüm paketler bilgisayarınızda mevcut. Yüklemek için " + ProjeNe.ProjeBaslik + " YÜKLE butonuna basınız.";
                        KurulumTuru = 2;
                    }
                    else
                    {
                        button1.Text = "İNDİR";
                        checkBox1.Checked = true;
                        checkBox1.Enabled = false;
                        islemhaberi = dosyaparcasi.Count + " adet paket indirilecek..." + "      Toplam Paket: " + mevcutpaket + "/" + toplampaket;
                    }
                }
                else
                {
                    progressBar2.Value = Convert.ToInt32(ProjeNe.ProjePaketSayisi) + 100;
                    kaynakklasor = yuklenenyer;
                    button1.Text = ProjeNe.ProjeBaslik + " YÜKLE";
                    checkBox1.Checked = false;
                    islemhaberi = "Kurulum paketleri bilgisayarınızda mevcut! Yüklemek için " + ProjeNe.ProjeBaslik + " YÜKLE butona basınız!";
                    KurulumTuru = 3;
                }
            }
            else
            {
                progressBar2.Value = Convert.ToInt32(ProjeNe.ProjePaketSayisi) + 100;
                kaynakklasor = bulunduguyer;
                button1.Text = ProjeNe.ProjeBaslik + " YÜKLE";
                checkBox1.Checked = false;
                islemhaberi = "Kurulum paketleri bilgisayarınızda mevcut!. Kurulum için " + ProjeNe.ProjeBaslik + " YÜKLE butona basınız!";
                KurulumTuru = 3;
            }
            //ESKİ BİTİŞ
            if (yenidenyukleme == 0)
            {
                if (Directory.Exists(data1))
                {
                    DialogResult dialogResult = MessageBox.Show("Bilgisayarınızda yüklü bir " + ProjeNe.ProjeBaslik + " uygulaması bulundu.\nYeni sürümle değiştirmek istiyor musunuz?.\nUygulamayı başlatmak için HAYIR butonuna basınız.", "Uyarı!", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {
                        button1.Text = "Yeniden Kurulum Yap!";
                    }
                    else if (dialogResult == DialogResult.No)
                    {
                        progressBar1.Value = 100;
                        progressBar2.Value = Convert.ToInt32(ProjeNe.ProjePaketSayisi) + 200;
                        button2.Text = "KAPAT";
                        button1.Text = ProjeNe.ProjeBaslik + " klasörüne git!";
                        islemhaberi = "Bilgisayarınızın güvenlik ayarları otomatik başlatmaya izin vermiyor... Yönetici olarak başlatın!";
                    }
                }
            }
        }
        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

            //   backgroundWorker1.ReportProgress(Prog1);
            if (KurulumTuru == 2)
            {
                int Prog1 = 0;
                try
                {
                    islemhaberi = "Paketler birleştiriliyor...";

                        FileStream outFile = new FileStream(kaynakklasor + @"\Data1.zip", FileMode.OpenOrCreate, FileAccess.Write);
                        int toplamzipdosya = Convert.ToInt32(ProjeNe.ProjePaketSayisi);
                        int carpan = 1;
                        if (toplamzipdosya < 10)
                        {
                            carpan = 10;
                        }
                        else if (toplamzipdosya < 20)
                        {
                            carpan = 5;
                        }
                        else if (toplamzipdosya < 50)
                        {
                            carpan = 2;
                        }
                        else
                        {
                            carpan = 1;
                        }
                        int acilan = 0;
                        for (int y = 0; y < Convert.ToInt32(ProjeNe.ProjePaketSayisi); y++)
                        {
                            if (acilan >= 100)
                            {
                                Prog1 = 100;
                            }
                            else
                            {
                                Prog1 = acilan * carpan;
                            }
                            int data = 0;
                            byte[] buffer = new byte[1024];
                            FileStream inFile = new FileStream(kaynakklasor + @"\Data1p" + y + ".zip", FileMode.OpenOrCreate, FileAccess.Read);
                            while ((data = inFile.Read(buffer, 0, 1024)) > 0)
                            {
                                outFile.Write(buffer, 0, data);
                            }
                            inFile.Close();
                            backgroundWorker1.ReportProgress(Prog1);
                            acilan++;
                        }
                        outFile.Flush();
                        outFile.Close();
                    KurulumTuru = 3;
                }
                catch (Exception)
                {
                    KurulumTuru = 0;
                }
            }
            if (KurulumTuru == 3)
            {

                if (Directory.Exists(data1))
                {
                    DialogResult dialogResult = MessageBox.Show("C: sürücüsünde "+ProjeNe.ProjeYukleYolu+" adlı bir klasör bulundu.\nYeni sürümle değiştirmek için üzerine yazılacaktır.\nOnaylıyor musunuz?", "Uyarı!", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {
                        try
                        {
                            //clearFolder(data1);
                            //Directory.Delete(data1);
                            islemhaberi = "Kurulum için hazırlanıyor...";
                            KurulumTuru = 4;
                        }
                        catch (Exception)
                        {
                            DialogResult kurulumhata1 = MessageBox.Show("Bilgisayarınızın güvenlik ayarlarından dolayı\nC: sürücüsündeki " + ProjeNe.ProjeYukleYolu + " klasörü silinemedi.\nLütfen " + ProjeNe.ProjeYukleYolu + " klasörünü silip tekrar deneyiniz", "Uyarı!", MessageBoxButtons.OK);
                            //if (kurulumhata1 == DialogResult.Yes)
                            //{
                            //    button1.Text = "Yeniden Kurulum Yap!";
                            //}
                            //    MessageBox.Show("Bilgisayarınızın güvenlik ayarlarından dolayı\nC: sürücüsündeki Jadde klasörü silinemedi.\nLütfen Jadde klasörünü silip tekrar deneyiniz");
                            islemhaberi = "C: sürücüsünde " + ProjeNe.ProjeYukleYolu + " klasörünü siliniz. Tekrar deneyiniz!";
                            KurulumTuru = 0;
                        }
                    }
                    else if (dialogResult == DialogResult.No)
                    {
                        islemhaberi = "C: sürücüsünde " + ProjeNe.ProjeYukleYolu + " klasörünü siliniz. Tekrar deneyiniz!";
                        KurulumTuru = 0;
                    }
                }
                else
                {
                    KurulumTuru = 4;
                    islemhaberi = "Yükleniyor... Lütfen bekleyiniz...";
                }
            }
            if (KurulumTuru == 4)
            {
                int iProgressPercentage = 0;

                //       backgroundWorker1.ReportProgress(iProgressPercentage);
                try
                {
                    // islemhaberi = "Grafik dosyaları yükleniyor...";
                    if (!Directory.Exists(data1))
                    {
                        Directory.CreateDirectory(data1);
                    }

                    using (ZipFile zip1 = ZipFile.Read(kaynakklasor + @"\Data1.zip"))
                    {
                        int toplamzipdosya = zip1.Count;
                        int carpan = 1;
                        if (toplamzipdosya <10)
                        {
                            carpan = 10;
                        }
                        else if (toplamzipdosya <20)
                        {
                            carpan = 5;
                        }
                        else if (toplamzipdosya <50)
                        {
                            carpan = 2;
                        }
                        else
                        {
                            carpan = 1;
                        }
                        int acilan = 0;
                        // here, we extract every entry, but we could extract conditionally
                        // based on entry name, size, date, checkbox status, etc.  
                        foreach (ZipEntry zip11 in zip1)
                        {   
                            acilan++;
                            if (acilan >= 100)
                            {
                                iProgressPercentage = 100;
                            }
                            else
                            {
                            iProgressPercentage = acilan * carpan;
                            }
                            islemhaberi = "%"+ iProgressPercentage +" yükleniyor... Lütfen bekleyiniz...";
                            backgroundWorker1.ReportProgress(iProgressPercentage);
                            zip11.Extract(data1, ExtractExistingFileAction.OverwriteSilently);

                        }
                    }
                    //        ZipFile.ExtractToDirectory(kaynakklasor + @"\Data1.zip", data1);
                    //using (ZipFile zip3 = ZipFile.Read(kaynakklasor + @"\Data1.zip"))
                    //{
                    //    //   zip3.BufferSize = 1024;
                    //    foreach (ZipEntry zip33 in zip3)
                    //    {
                    //        string tempName = data1 + zip33.FileName;
                    //        string oldName = zip33.FileName;
                    //        Stream inStream = null;
                    //        FileStream stream = new FileStream(tempName, FileMode.Create, FileAccess.ReadWrite);
                    //        for (int zz = 0; zz < 1; zz++)
                    //        {
                    //            int data = 0;
                    //            byte[] buffer = new byte[1024];
                    //            inStream = zip33.OpenReader();
                    //            while ((data = inStream.Read(buffer, 0, buffer.Length)) > 0)
                    //            {
                    //                stream.Write(buffer, 0, data);
                    //            }
                    //            inStream.Close();
                    //        }
                    //        stream.Flush();
                    //        stream.Close();
                    //    }
                    //}
                    KurulumTuru = 5;
                }
                catch (Exception)
                {
                    KurulumTuru = 0;
                }
            }
            if (KurulumTuru == 5)
            {

                    WshShell shell = new WshShell();
                if (ProjeNe.Masaustu == "1")
                {
                    string DesktopFolder = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);

                    IWshShortcut link = (IWshShortcut)shell.CreateShortcut(DesktopFolder + @"\"+ProjeNe.ProjeKisayolAdi+".lnk");
                    link.Description = "Bu uygulama " + ProjeNe.ProjeSahibi + " ürünüdür.";
                    link.IconLocation = data1 + @"\"+ProjeNe.ProjeExeDosya+", 0";//"cmd.exe, 0";
                    link.TargetPath = data1 + @"\" + ProjeNe.ProjeExeDosya;
                    link.WorkingDirectory = data1;
                    link.Save();
                }
                if (ProjeNe.Baslangic == "1")
                {
                    string DesktopFolder = Environment.GetFolderPath(Environment.SpecialFolder.StartMenu) + @"\Programs";
                    IWshShortcut link = (IWshShortcut)shell.CreateShortcut(DesktopFolder + @"\" + ProjeNe.ProjeKisayolAdi + ".lnk");
                    link.Description = "Bu uygulama " + ProjeNe.ProjeSahibi + " ürünüdür.";
                    link.IconLocation = data1 + @"\" + ProjeNe.ProjeExeDosya + ", 0";//"cmd.exe, 0";
                    link.TargetPath = data1 + @"\" + ProjeNe.ProjeExeDosya;
                    link.WorkingDirectory = data1;
                    link.Save();
                }
                if (ProjeNe.Programlar == "1")
                {
                    string DesktopFolder = Environment.GetFolderPath(Environment.SpecialFolder.Startup);
                    IWshShortcut link = (IWshShortcut)shell.CreateShortcut(DesktopFolder + @"\" + ProjeNe.ProjeKisayolAdi + ".lnk");
                    link.Description = "Bu uygulama " + ProjeNe.ProjeSahibi + " ürünüdür.";
                    link.IconLocation = data1 + @"\" + ProjeNe.ProjeExeDosya + ", 0";//"cmd.exe, 0";
                    link.TargetPath = data1 + @"\" + ProjeNe.ProjeExeDosya;
                    link.WorkingDirectory = data1;
                    link.Save();
                }
                islemhaberi = "Yükleme başarıyla tamamlandı!";
                KurulumTuru = 6;
                //    buton2 = "Bitti"; 
 
                //      MessageBox.Show("Yükleme başarıyla tamamlandı!\nOyunu başlatmak için MASAÜSTÜ'ndeki JADDE simgesine tıklayınız!\nHatasız bir başlatma için YÖNETİCİ OLARAK çalıştırınız");
            }
        }
        private void clearFolder(string FolderName)
        {
            DirectoryInfo dir = new DirectoryInfo(FolderName);

            foreach (FileInfo fi in dir.GetFiles())
            {
                fi.Delete();
            }

            foreach (DirectoryInfo di in dir.GetDirectories())
            {
                clearFolder(di.FullName);
                di.Delete();
            }
        }
        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            int birinci = e.ProgressPercentage;
            label3.Text = islemhaberi;

            if (KurulumTuru == 2)
            {
                progressBar1.Value = birinci;
                progressBar2.Value = Convert.ToInt32(ProjeNe.ProjePaketSayisi) + (birinci);
            }
            else if (KurulumTuru == 4)
            {
                progressBar1.Value = birinci;
                progressBar2.Value = Convert.ToInt32(ProjeNe.ProjePaketSayisi)+100 + (birinci);
            }

        }
        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            label3.Text = islemhaberi;
            button2.Text = "Bitti";
            button1.Enabled = false;
            button1.Text = "Yükleme Tamamlandı";
            progressBar1.Value = 100;
            progressBar2.Value = Convert.ToInt32(ProjeNe.ProjePaketSayisi) + 200;
            DialogResult kurulumhata1 = MessageBox.Show("Yükleme başarıyla tamamlandı!\nUygulamayı başlatmak için MASAÜSTÜ'ndeki " + ProjeNe.ProjeKisayolAdi + " simgesine tıklayınız!\nHatasız bir başlatma için YÖNETİCİ OLARAK çalıştırınız", "Uyarı!", MessageBoxButtons.OK);
        }
        private bool downloadData(string url)
        {
            Thread.Sleep(300);
            Stopwatch speedtimer = new Stopwatch();
            progressBar1.Value = 0;
            downloadedData = new byte[0];
            button1.Enabled = false;
            try
            {           
                label3.Text = "Bağlanıyor...";
                Application.DoEvents();
                WebRequest req = WebRequest.Create(url);
                WebResponse response = req.GetResponse();
                Stream stream = response.GetResponseStream();
                stream.ReadTimeout = System.Threading.Timeout.Infinite;
                byte[] buffer = new byte[1024];
                int dataLength = (int)response.ContentLength;
                inenboyut += dataLength;
                progressBar1.Maximum = dataLength;
                label3.Text = "0/" + dataLength.ToString();
                label3.Text = "İndiriliyor...";
                Application.DoEvents();
                MemoryStream memStream = new MemoryStream();
                int bytesRead = 1;
                int deger = 0;
                double currentspeed = -1;
                string tahminikalansure = string.Empty;
                double tahminikalansaniye = 0;
                int readings = 0;
                string time = string.Empty;
                TimeSpan ts = new TimeSpan();
                while (InternetGetConnectedState(out deger, 0))//(bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
                {
                    try
                    {
                        speedtimer.Start();
                        bytesRead = stream.Read(buffer, 0, buffer.Length);
                        speedtimer.Stop();
                        readings += 1;
                        if (readings >= 100)
                        {
                          //  ((int)(((current - previous) / (double)1024) / ((ctime - ptime) / (double)1000))).ToString() + " Kbps";
                            currentspeed = (102400 * 1024) / speedtimer.ElapsedMilliseconds;///(double)1000;//51200 / (speedtimer.ElapsedTicks) * 1024;// / 1000);
                            tahminikalansaniye = (((indkalanpaket+1) * dataLength) / currentspeed) + indkalanpaket*2;
                            ts = TimeSpan.FromSeconds(tahminikalansaniye);
                            tahminikalansure =  String.Format("{0:00}:{1:00}:{2:00}",ts.Hours, ts.Minutes, ts.Seconds);
                            speedtimer.Reset();
                            readings = 0;
                        }
                    }
                    catch (Exception)
                    {
                        return false;
                    }
                    if (bytesRead == 0)
                    {
                        progressBar1.Value = progressBar1.Maximum;
                        label3.Text = dataLength.ToString() + "/" + dataLength.ToString() + " Hız: " + Math.Round((currentspeed / 1024), 0) + " KB/s. Tahmini Bitiş Süresi: " + tahminikalansure;//+ string.Format("{0:HH:mm:ss}", TimeSpan.FromSeconds(tahminikalansaniye));
                        Application.DoEvents();
                        break;
                    }
                    else
                    {
                        memStream.Write(buffer, 0, bytesRead);
                        if (progressBar1.Value + bytesRead <= progressBar1.Maximum)
                        {
                            progressBar1.Value += bytesRead;
                            label3.Text = progressBar1.Value.ToString() + "/" + dataLength.ToString() + " Hız: " + Math.Round((currentspeed / 1024), 0) + " KB/s. Tahmini Bitiş Süresi: " +tahminikalansure;//+ string.Format("{0:HH:mm:ss}", TimeSpan.FromSeconds(tahminikalansaniye));
                            progressBar1.Refresh();
                            Application.DoEvents();
                        }
                    }
                }
                //DownloadCompleteSafe completeDelegate = new DownloadCompleteSafe(DownloadComplete);

                //this.Invoke(completeDelegate, false);
                downloadedData = memStream.ToArray();
                stream.Close();
                memStream.Close();
                label3.Text = downloadedData.Length.ToString();
                label3.Text = "Bağlantı hatası veya geçerli dosya bulunamadı.";
            }
            catch (Exception)
            {
                downloadedData = new byte[0];
                return false;
            }
            return true;
        }
        public int indkalanpaket = 0;
        private bool indirmeIslemi()
        {
            string urlAddress = string.Empty;
         //   int indkalanpaket = 0;
            int indtoplampaket = 0;
            indtoplampaket = dosyaparcasi.Count;
            int indirmesirasi = 0;
            foreach (icerik item in dosyaparcasi)
            {
                if (indirmeislemiaktif == 1)
                {
                    FileInfo TheFile = new FileInfo(item.dosyaadi);
                    if (!TheFile.Exists)
                    {
                        indirmesirasi++;
                        indkalanpaket = indtoplampaket - indirmesirasi;
                        label1.Text = indkalanpaket + " adet paket kaldı. Toplam: " + indtoplampaket;
                        progressBar2.Value = (Convert.ToInt32(ProjeNe.ProjePaketSayisi) - indtoplampaket) + indirmesirasi;
                        urlAddress = item.degeri;
                        Uri URL2 = urlAddress.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ? new Uri(urlAddress) : new Uri("http://" + urlAddress);
                        if (downloadData(URL2.ToString()))
                        {
                            if (downloadedData != null && downloadedData.Length != 0)
                            {
                                string urlName = URL2.ToString();
                                if (urlName.EndsWith("/")) urlName = urlName.Substring(0, urlName.Length - 1); //Chop off the last '/'
                                urlName = urlName.Substring(urlName.LastIndexOf('/') + 1);
                                saveFileDialog1.FileName = kaynakklasor + @"\" + item.dosyaadi;//download1+"Data1.zip";
                                if (downloadedData != null && downloadedData.Length != 0)
                                {
                                    label3.Text = "Kaydediliyor...";
                                    Application.DoEvents();
                                    FileStream newFile = new FileStream(saveFileDialog1.FileName, FileMode.Create);
                                    newFile.Write(downloadedData, 0, downloadedData.Length);
                                    newFile.Close();
                                    label3.Text = "Dosya indirildi.";
                                }
                                else
                                {
                                    DialogResult kurulumhata4 = MessageBox.Show("Geçerli dosya bulunamadı!", "Uyarı!", MessageBoxButtons.OK);
                                }
                            }
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
            }
            return true;
        }
        private bool SozlesmeKabul() {
            if (cbSozlesme.Checked==false)
            {
                MessageBox.Show("Sözleşmeyi okuyup kabul ediniz!\nSözleşmeyi kabul etmiyorsanız İPTAL veya KAPAT butonuna basarak kurulumu iptal ediniz!");
                return false;
            }
            return true;
        }
        public static bool InternetVarmi()
        {
            return new System.Net.NetworkInformation.Ping().Send("www.google.com", 10).Status == System.Net.NetworkInformation.IPStatus.Success;
        }
        private void button1_Click(object sender, EventArgs e)
        {

            if (button1.Text == ProjeNe.ProjeBaslik + " YÜKLE")
            {
                button1.Enabled = false;
                if (checkBox1.Checked)
                {
                    if (SozlesmeKabul())
                    {
                        indirmeislemiaktif = 1;
                        if (indirmeIslemi())
                        {
                            button1.Text = "ÇIKIŞ";
                            kuradet = 0;
                            FileInfo TheFile = new FileInfo(kaynakklasor + @"\Data1.zip");
                            if (TheFile.Exists)
                            {
                                kuradet++;
                            }
                            if (kuradet < 1)
                            { KurulumTuru = 2; }
                            else
                            {
                                KurulumTuru = 3;
                            }
                            backgroundWorker1.RunWorkerAsync();
                            if (KurulumTuru == 6)
                            {
                                button1.Enabled = true;
                                progressBar2.Value = Convert.ToInt32(ProjeNe.ProjePaketSayisi) + 200;
                            }
                            else
                            {
                                progressBar2.Value = 0;
                            }
                            label3.Text = islemhaberi;
                        }
                        else
                        {
                            label3.Text = "İnternet bağlantınız veya sunucuyla ilgili problem var. Dosyalar indirilemiliyor...";
                            button2.Text = "KAPAT";
                        }
                    }
                }
                else
                {
                    if (SozlesmeKabul())
                    {
                        button1.Enabled = false;
                        kuradet = 0;
                        FileInfo TheFile = new FileInfo(kaynakklasor + @"\Data1.zip");
                        if (TheFile.Exists)
                        {
                            kuradet++;
                        }
                        if (kuradet < 1)
                        { KurulumTuru = 2; }
                        else
                        {
                            KurulumTuru = 3;
                        }
                        backgroundWorker1.RunWorkerAsync();
                        if (KurulumTuru == 6)
                        {
                            button1.Enabled = true;
                            progressBar2.Value = Convert.ToInt32(ProjeNe.ProjePaketSayisi) + 200;
                        }
                        else
                        {
                            progressBar2.Value = 0;
                        }
                        label3.Text = islemhaberi;
                    }
                }
            }
            else if (button1.Text == "İNDİR")
            {
                if (SozlesmeKabul())
                {
                    indirmeislemiaktif = 1;
                    try
                    {
                        if (indirmeIslemi())
                        {
                            label1.Text = "";
                            label3.Text = "Tüm paketler bilgisayarınıza indirildi. Yüklemek için " + ProjeNe.ProjeBaslik + " YÜKLE butonuna basınız.";
                            checkBox1.Checked = false;
                            checkBox1.Enabled = false;
                            button1.Enabled = false;
                            progressBar1.Maximum = 100;
                            progressBar1.Step = 1;
                            kuradet = 0;
                            FileInfo TheFile = new FileInfo(kaynakklasor + @"\Data1.zip");
                            if (TheFile.Exists)
                            {
                                kuradet++;
                            }
                            if (kuradet < 1)
                            { KurulumTuru = 2; }
                            else
                            {
                                KurulumTuru = 3;
                            }
                            backgroundWorker1.RunWorkerAsync();
                            if (KurulumTuru == 6)
                            {
                                button1.Enabled = true;
                                progressBar2.Value = Convert.ToInt32(ProjeNe.ProjePaketSayisi) + 200;
                            }
                            label3.Text = islemhaberi;
                        }
                    }
                    catch (Exception)
                    {
                        label3.Text = "İnternet bağlantınız veya sunucuyla ilgili problem var. Dosyalar indirilemiliyor...";
                        button2.Text = "KAPAT";
                    }
                }


            }
            else if (button1.Text == "Yeniden Kurulum Yap!")
            {
                if (SozlesmeKabul())
                {
                    yenidenyukleme = 1;
                    Kontrol();
                }
            }
            else if (button1.Text == ProjeNe.ProjeBaslik + " klasörüne git!")
            {
                Process.Start(data1);
            }
            else
            {
                this.Close();
            }
        }
        private void client_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            double bytesIn = double.Parse(e.BytesReceived.ToString());
            double totalBytes = double.Parse(e.TotalBytesToReceive.ToString());
            double percentage = bytesIn / totalBytes * 100;
            label3.Text = "Downloaded " + e.BytesReceived + " of " + e.TotalBytesToReceive;
            progressBar1.Value = int.Parse(Math.Truncate(percentage).ToString());
        }
        private void ProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            progressBar1.Value = e.ProgressPercentage;
        }
        private void client_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
        {
            button1.Text = ProjeNe.ProjeBaslik+" YÜKLE";
            button1.Enabled = true;
        }
        public class icerik
        {
            public int sirano { get; set; }
            public string degeri { get; set; }
            public string dosyaadi { get; set; }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            indirmeislemiaktif = 0;
            backgroundWorker1.CancelAsync();
            this.Close();
        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
            Process.Start(ProjeNe.UreticiAdres);
            }
            catch (Exception)
            {
            Process.Start("http://www.aytacsunar.com/AytacWebInstaller");
            }

        }
    }
}
